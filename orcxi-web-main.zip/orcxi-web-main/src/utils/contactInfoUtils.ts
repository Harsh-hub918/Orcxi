interface ContactInfo {
  email: string;
  phone: string;
  address: string;
}

const defaultContactInfo: ContactInfo = {
  email: "info@orcxi.com",
  phone: "+1 (555) 123-4567",
  address: "123 Business Ave, Tech City, CA 94101"
};

export const getContactInfo = (): ContactInfo => {
  try {
    const savedInfo = localStorage.getItem('orcxi-contact-info');
    if (savedInfo) {
      return JSON.parse(savedInfo);
    }
  } catch (error) {
    console.error("Error retrieving contact info:", error);
  }
  
  return defaultContactInfo;
};

export const getPrivacyPolicy = () => {
  try {
    const savedPolicy = localStorage.getItem('orcxi-privacy-policy');
    if (savedPolicy) {
      return JSON.parse(savedPolicy);
    }
  } catch (error) {
    console.error("Error retrieving privacy policy:", error);
  }
  
  return {
    title: "Privacy Policy",
    content: "Our privacy policy has not been set up yet. Please check back later.",
    lastUpdated: new Date().toISOString().split('T')[0]
  };
};

export const saveImageToLocalStorage = (imageFile: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onloadend = () => {
      try {
        const base64String = reader.result as string;
        const imageKey = `orcxi-image-${Date.now()}`;
        
        // Store the image in localStorage
        localStorage.setItem(imageKey, base64String);
        
        // Keep track of all images stored
        const savedImages = JSON.parse(localStorage.getItem('orcxi-saved-images') || '[]');
        savedImages.push(imageKey);
        localStorage.setItem('orcxi-saved-images', JSON.stringify(savedImages));
        
        resolve(imageKey);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = reject;
    reader.readAsDataURL(imageFile);
  });
};

export const getImageFromLocalStorage = (imageKey: string): string | null => {
  return localStorage.getItem(imageKey);
};
