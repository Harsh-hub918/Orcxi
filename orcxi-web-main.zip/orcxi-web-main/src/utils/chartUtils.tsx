
import React from 'react';

export interface CellProps {
  key?: string;
  fill?: string;
}

export const Cell: React.FC<CellProps> = ({ fill }) => {
  return null; // This is a placeholder component for the recharts Cell
};
