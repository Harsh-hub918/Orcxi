
import { createClient } from '@supabase/supabase-js';

// Get environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Create a mock client when environment variables are missing
let supabase;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables. Using mock client.');
  
  if (!supabaseUrl) {
    console.error('Missing VITE_SUPABASE_URL environment variable');
  }
  
  if (!supabaseAnonKey) {
    console.error('Missing VITE_SUPABASE_ANON_KEY environment variable');
  }
  
  // Create a mock client that logs operations instead of throwing errors
  supabase = {
    from: (table) => ({
      select: () => {
        console.log(`Mock: select from ${table}`);
        return { data: [], error: null, count: 0, single: () => ({ data: null, error: null }) };
      },
      insert: (data) => {
        console.log(`Mock: insert into ${table}`, data);
        return { data: null, error: null };
      },
      update: (data) => {
        console.log(`Mock: update ${table}`, data);
        return { data: null, error: null };
      },
      upsert: (data) => {
        console.log(`Mock: upsert ${table}`, data);
        return { data: null, error: null };
      },
      delete: () => {
        console.log(`Mock: delete from ${table}`);
        return { data: null, error: null };
      },
      eq: () => ({
        single: () => ({ data: null, error: null }),
        delete: () => ({ error: null }),
      }),
    }),
    storage: {
      from: () => ({
        upload: () => Promise.resolve({ data: null, error: null }),
        getPublicUrl: () => ({ data: { publicUrl: '' } }),
      }),
    },
    auth: {
      signIn: () => Promise.resolve({ user: null, session: null, error: null }),
      signOut: () => Promise.resolve({ error: null }),
      onAuthStateChange: () => ({ data: null, error: null, unsubscribe: () => {} }),
    },
  };
} else {
  // Create a real supabase client
  supabase = createClient(supabaseUrl, supabaseAnonKey);
}

export default supabase;
