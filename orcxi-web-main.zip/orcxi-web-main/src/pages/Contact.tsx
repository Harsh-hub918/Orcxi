
import { useState, useEffect } from 'react';
import { Send, Mail, MapPin, Phone, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { motion } from 'framer-motion';

const ContactPage = () => {
  const { toast } = useToast();
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    
    // Simulate API call
    setTimeout(() => {
      // Success scenario
      if (formState.email && formState.message) {
        setFormStatus('success');
        toast({
          title: "Message sent!",
          description: "Thank you for reaching out. I'll get back to you soon.",
          variant: "default",
        });
        setFormState({
          name: '',
          email: '',
          subject: '',
          message: ''
        });
      } else {
        // Error scenario
        setFormStatus('error');
        toast({
          title: "Error",
          description: "Something went wrong. Please try again.",
          variant: "destructive",
        });
      }
    }, 1500);
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-16">
      {/* Hero Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            className="text-center space-y-6 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-block">
              <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-2">
                <span className="text-muted-foreground">Contact</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Let's <span className="text-primary">Connect</span>
            </h1>
            
            <p className="text-muted-foreground text-lg">
              We're always interested in new projects and collaborations. Feel free to reach out for any inquiries.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Contact Information Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {[
              {
                icon: Mail,
                title: "Email",
                details: "contact@orcxi.com",
                link: "mailto:contact@orcxi.com"
              },
              {
                icon: MapPin,
                title: "Location",
                details: "Pune, Maharashtra, India"
              },
              {
                icon: Phone,
                title: "Phone",
                details: "+91 (987) 654-3210",
                link: "tel:+919876543210"
              }
            ].map((item, index) => (
              <motion.div 
                key={index} 
                className="bg-secondary/50 rounded-2xl p-6 text-center hover:bg-secondary/70 transition-colors duration-300"
                variants={itemVariants}
              >
                <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-bold text-xl mb-2">{item.title}</h3>
                {item.link ? (
                  <a href={item.link} className="text-muted-foreground hover:text-primary transition-colors">
                    {item.details}
                  </a>
                ) : (
                  <p className="text-muted-foreground">{item.details}</p>
                )}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* Contact Form Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold">Send a Message</h2>
              <p className="text-muted-foreground">
                Have a project in mind or want to discuss a potential collaboration? Use the form to get in touch, and I'll respond as soon as possible.
              </p>
              
              <div className="mt-8 space-y-6">
                <motion.div 
                  className="relative"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-blue rounded-2xl opacity-10 blur-3xl"></div>
                  <div className="relative bg-background/80 backdrop-blur-md rounded-2xl p-8 border border-border">
                    <h3 className="font-bold text-xl mb-4">Working Hours</h3>
                    <ul className="space-y-3">
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">Monday - Friday</span>
                        <span>9:00 AM - 6:00 PM</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">Saturday</span>
                        <span>10:00 AM - 2:00 PM</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">Sunday</span>
                        <span>Closed</span>
                      </li>
                    </ul>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="relative"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-blue rounded-2xl opacity-10 blur-3xl"></div>
                  <div className="relative bg-background/80 backdrop-blur-md rounded-2xl p-8 border border-border">
                    <h3 className="font-bold text-xl mb-4">Project Inquiry</h3>
                    <p className="text-muted-foreground mb-4">
                      For project-specific inquiries, please include:
                    </p>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary mt-2"></span>
                        <span>Project type and scope</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary mt-2"></span>
                        <span>Estimated timeline</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary mt-2"></span>
                        <span>Budget range (if applicable)</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary mt-2"></span>
                        <span>Any specific requirements</span>
                      </li>
                    </ul>
                  </div>
                </motion.div>
              </div>
            </div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label 
                      htmlFor="name" 
                      className="text-sm font-medium text-foreground"
                    >
                      Your Name
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      value={formState.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      placeholder="John Doe"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label 
                      htmlFor="email" 
                      className="text-sm font-medium text-foreground"
                    >
                      Email Address <span className="text-destructive">*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      value={formState.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label 
                    htmlFor="subject" 
                    className="text-sm font-medium text-foreground"
                  >
                    Subject
                  </label>
                  <input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formState.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-2 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    placeholder="Project Inquiry"
                  />
                </div>
                
                <div className="space-y-2">
                  <label 
                    htmlFor="message" 
                    className="text-sm font-medium text-foreground"
                  >
                    Message <span className="text-destructive">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formState.message}
                    onChange={handleChange}
                    rows={6}
                    className="w-full px-4 py-2 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    placeholder="Tell me about your project..."
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={formStatus === 'submitting'}
                  className={`button-main w-full ${
                    formStatus === 'submitting' ? 'opacity-70 cursor-not-allowed' : ''
                  }`}
                >
                  {formStatus === 'submitting' ? (
                    <div className="flex items-center justify-center">
                      <span className="animate-pulse mr-2 h-2 w-2 rounded-full bg-white"></span>
                      <span className="animate-pulse mr-2 h-2 w-2 rounded-full bg-white" style={{ animationDelay: "0.2s" }}></span>
                      <span className="animate-pulse mr-2 h-2 w-2 rounded-full bg-white" style={{ animationDelay: "0.4s" }}></span>
                      <span>Sending...</span>
                    </div>
                  ) : formStatus === 'success' ? (
                    <div className="flex items-center justify-center">
                      <CheckCircle className="mr-2 h-4 w-4" />
                      <span>Message Sent!</span>
                    </div>
                  ) : formStatus === 'error' ? (
                    <div className="flex items-center justify-center">
                      <AlertCircle className="mr-2 h-4 w-4" />
                      <span>Try Again</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Send className="mr-2 h-4 w-4" />
                      <span>Send Message</span>
                    </div>
                  )}
                </button>
                
                <p className="text-xs text-muted-foreground text-center">
                  By submitting this form, you agree to my <a href="#" className="text-primary hover:underline">privacy policy</a>.
                </p>
              </form>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            className="overflow-hidden rounded-2xl bg-secondary/50 h-80 relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d242118.14199662278!2d73.72288094868724!3d18.524564859944024!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf2e67461101%3A0x828d43bf9d9ee343!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1689233045017!5m2!1sen!2sin" 
              className="w-full h-full border-0"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Map showing Pune, Maharashtra, India"
            ></iframe>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
