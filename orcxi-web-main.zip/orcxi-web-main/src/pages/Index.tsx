
import { motion } from "framer-motion";
import ServicesSection from "@/components/ServicesSection";
import TrendingSection from "@/components/TrendingSection";
import PartnersSection from "@/components/PartnersSection";
import CompletedProjects from "@/components/CompletedProjects";
import OrcxiOffersSection from "@/components/OrcxiOffersSection";
import Logo from "@/components/Logo";  // Ensure Logo import

const Index = () => {
  return (
    <div>
      <section className="relative py-24 bg-background">
        <div className="container px-4 mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto text-center relative"
          >
            {/* Logo with bigger default size */}
            <div className="flex justify-center mb-8">
              <Logo size="xl" />
            </div>
            
            <h1 className="text-5xl font-bold mb-6">
              Building Digital Success, One Pixel at a Time
            </h1>
            <p className="text-xl mb-8 text-muted-foreground">
              Web development, design, and digital marketing solutions to help your business thrive in the digital landscape.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <motion.a
                href="#services"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-md font-medium"
              >
                Our Services
              </motion.a>
              <motion.a
                href="/contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border border-primary text-primary hover:bg-primary/10 px-8 py-3 rounded-md font-medium"
              >
                Get in Touch
              </motion.a>
            </div>
          </motion.div>
        </div>
        
        {/* Animated background circle */}
        <motion.div 
          className="absolute inset-0 z-0 opacity-30"
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 10, -10, 0],
            borderRadius: ["50%", "40%", "60%", "50%"]
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{
            background: 'radial-gradient(circle, rgba(59,130,246,0.2) 0%, rgba(59,130,246,0.1) 70%)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '80%',
            height: '80%',
            position: 'absolute'
          }}
        />
      </section>

      {/* What Orcxi Offers Section */}
      <OrcxiOffersSection />
      <ServicesSection />
      <CompletedProjects />
      <TrendingSection />
      <PartnersSection />
    </div>
  );
};

export default Index;
