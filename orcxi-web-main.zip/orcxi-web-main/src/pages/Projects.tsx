
import { useState } from 'react';
import { ExternalLink, ArrowRight, Github, Link as LinkIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Logo from '@/components/Logo';

const ProjectsPage = () => {
  const [filter, setFilter] = useState('all');
  
  const categories = [
    { id: 'all', label: 'All' },
    { id: 'web', label: 'Web Design' },
    { id: 'mobile', label: 'Mobile Apps' },
    { id: 'branding', label: 'Branding' }
  ];
  
  const projects = [
    {
      id: 1,
      title: "Wave Analytics Dashboard",
      description: "A data visualization dashboard with a focus on UX and clean design. Built with React, TypeScript, and D3.js, featuring real-time data updates and interactive charts.",
      category: "web",
      image: "bg-gradient-blue",
      tags: ["React", "TypeScript", "Data Viz"],
      link: "#",
      github: "#",
      featured: true
    },
    {
      id: 2,
      title: "Serene Mobile App",
      description: "Meditation and mindfulness app with custom audio visualizations. Includes guided sessions, sleep stories, and personalized recommendations based on user preferences.",
      category: "mobile",
      image: "bg-gradient-blue",
      tags: ["React Native", "Animation", "UI Design"],
      link: "#",
      github: "#",
      featured: true
    },
    {
      id: 3,
      title: "Oceanic Brand Identity",
      description: "Complete brand redesign for an ocean conservation non-profit. Delivered a comprehensive brand package including logo design, color palette, typography guidelines, and marketing materials.",
      category: "branding",
      image: "bg-gradient-blue",
      tags: ["Branding", "Logo Design", "Identity"],
      link: "#",
      featured: true
    },
    {
      id: 4,
      title: "Finance Portal",
      description: "Secure financial management interface with advanced filtering capabilities. Features include transaction tracking, budget planning, and data visualization for financial analysis.",
      category: "web",
      image: "bg-gradient-blue",
      tags: ["React", "Node.js", "Authentication"],
      link: "#",
      github: "#"
    },
    {
      id: 5,
      title: "Travel Companion App",
      description: "Location-based travel app with personalized recommendations. Helps users discover local attractions, restaurants, and experiences based on their preferences and current location.",
      category: "mobile",
      image: "bg-gradient-blue",
      tags: ["Flutter", "Maps API", "UX Research"],
      link: "#",
      github: "#"
    },
    {
      id: 6,
      title: "Minimal Photography",
      description: "Brand identity and website for a professional photographer. Created a minimal, elegant design that showcases the photographer's portfolio while maintaining focus on the imagery.",
      category: "branding",
      image: "bg-gradient-blue",
      tags: ["Branding", "Web Design", "Photography"],
      link: "#"
    }
  ];
  
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);
  
  // Get featured projects
  const featuredProjects = projects.filter(project => project.featured);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-16">
      {/* Hero Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            className="text-center space-y-6 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-block">
              <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-2">
                <span className="text-muted-foreground">My Work</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Selected <span className="text-primary">Projects</span>
            </h1>
            
            <p className="text-muted-foreground text-lg">
              A curated collection of my best work in design and development. Each project represents a unique challenge and solution.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Featured Projects Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-16">
            <h2 className="text-3xl font-bold">Featured Projects</h2>
            <p className="text-muted-foreground max-w-2xl">
              Highlighted projects that showcase my skills and approach to design and development.
            </p>
          </div>
          
          <motion.div 
            className="space-y-16"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {featuredProjects.map((project, index) => (
              <motion.div 
                key={project.id} 
                className={`grid grid-cols-1 lg:grid-cols-2 gap-8 ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
                variants={itemVariants}
              >
                <div className={`${project.image} rounded-2xl h-64 md:h-96 relative overflow-hidden shadow-soft hover:shadow-strong transition-all duration-500`}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Logo size="md" />
                  </div>
                </div>
                
                <div className="flex flex-col justify-center space-y-6">
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag, tagIndex) => (
                        <span 
                          key={tagIndex} 
                          className="inline-block rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold">{project.title}</h3>
                    <p className="text-muted-foreground">{project.description}</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-4">
                    <a
                      href={project.link}
                      className="button-main"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <span>View Project</span>
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </a>
                    
                    {project.github && (
                      <a
                        href={project.github}
                        className="button-secondary"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Github className="mr-2 h-4 w-4" />
                        <span>Source Code</span>
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* All Projects Section */}
      <section className="section-padding bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-16">
            <h2 className="text-3xl font-bold">All Projects</h2>
            <div className="flex justify-between items-center flex-wrap gap-4">
              <p className="text-muted-foreground">
                Browse through all my projects or filter by category.
              </p>
              
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setFilter(category.id)}
                    className={`px-4 py-1 rounded-full transition-colors ${
                      filter === category.id 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-secondary/70 text-secondary-foreground hover:bg-secondary'
                    }`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredProjects.map((project) => (
              <motion.div 
                key={project.id} 
                className="rounded-2xl overflow-hidden bg-background shadow-soft hover:shadow-strong transition-all duration-500 group"
                variants={itemVariants}
              >
                <div className={`h-48 ${project.image} relative overflow-hidden`}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Logo size="sm" />
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex flex-wrap gap-2 mb-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex} 
                        className="inline-block rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="font-bold text-xl group-hover:text-primary transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground">{project.description}</p>
                  <div className="flex space-x-4">
                    <a 
                      href={project.link} 
                      className="inline-flex items-center text-primary hover:underline transition-all text-sm"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <LinkIcon className="mr-1 h-4 w-4" />
                      <span>Live Preview</span>
                    </a>
                    
                    {project.github && (
                      <a 
                        href={project.github} 
                        className="inline-flex items-center text-muted-foreground hover:text-primary transition-all text-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Github className="mr-1 h-4 w-4" />
                        <span>Source Code</span>
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* Contact CTA Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="rounded-2xl bg-gradient-blue text-white p-8 md:p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-90"></div>
            <div className="relative z-10 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Have a Project in Mind?</h2>
              <p className="text-white/80 text-lg mb-8">
                Let's collaborate to create something amazing together. I'm always open to new opportunities.
              </p>
              <Link 
                to="/contact" 
                className="inline-flex items-center justify-center rounded-full bg-white text-primary hover:bg-white/90 transition-all duration-300 px-6 py-3 shadow-soft"
              >
                <span>Start a Conversation</span>
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProjectsPage;
