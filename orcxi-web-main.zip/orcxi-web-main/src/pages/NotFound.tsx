
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { ArrowLeft, Home } from "lucide-react";
import { motion } from "framer-motion";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <motion.div 
      className="min-h-screen flex items-center justify-center bg-background px-4 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="text-center max-w-md">
        <motion.div 
          className="relative mx-auto h-24 w-24 mb-6"
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="absolute inset-0 bg-gradient-blue rounded-full opacity-20 blur-xl animate-pulse"></div>
          <div className="relative flex items-center justify-center h-full w-full">
            <h2 className="text-6xl font-display font-bold text-primary">404</h2>
          </div>
        </motion.div>
        
        <motion.h1 
          className="text-3xl font-bold mb-4"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.3 }}
        >
          Page Not Found
        </motion.h1>
        
        <motion.p 
          className="text-muted-foreground mb-8"
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.3 }}
        >
          The page you are looking for doesn't exist or has been moved.
        </motion.p>
        
        <motion.div 
          className="flex flex-col sm:flex-row justify-center gap-4"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.3 }}
        >
          <button 
            onClick={() => window.history.back()} 
            className="button-secondary flex items-center justify-center px-4 py-2 rounded-md bg-secondary text-foreground hover:bg-secondary/80 transition-all"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            <span>Go Back</span>
          </button>
          
          <Link 
            to="/" 
            className="button-main flex items-center justify-center px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-all"
          >
            <Home className="mr-2 h-4 w-4" />
            <span>Return Home</span>
          </Link>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default NotFound;
