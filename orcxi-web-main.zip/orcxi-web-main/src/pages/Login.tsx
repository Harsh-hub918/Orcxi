
import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Lock, LogIn, AlertCircle } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const Login = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const isSuccessful = login(password);
    
    if (isSuccessful) {
      toast({
        title: "Login successful",
        description: "Welcome back to the admin panel."
      });
      navigate('/admin');
    } else {
      setError('Invalid password. Please try again.');
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-16">
      <section className="section-padding">
        <div className="max-w-md mx-auto">
          <motion.div 
            className="text-center space-y-6 max-w-3xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-block">
              <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-2">
                <Lock className="w-4 h-4 mr-1" />
                <span className="text-muted-foreground">Admin Access</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Admin <span className="text-primary">Login</span>
            </h1>
          </motion.div>

          <Card>
            <CardHeader>
              <CardTitle>Administrator Login</CardTitle>
              <CardDescription>
                Please enter your password to access the admin panel.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                <div className="space-y-4">
                  <div>
                    <Input
                      type="password"
                      placeholder="Enter admin password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  
                  <Button type="submit" className="w-full flex items-center gap-2">
                    <LogIn className="w-4 h-4" />
                    <span>Login</span>
                  </Button>
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex justify-center text-sm text-muted-foreground">
              This area is restricted to site administrators only.
            </CardFooter>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Login;
