
import { useState, useEffect } from 'react';
import { Calendar, Clock, Search, ArrowRight, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTag, setActiveTag] = useState('all');
  const [filteredPosts, setFilteredPosts] = useState([]);
  
  const tags = [
    { id: 'all', label: 'All Posts' },
    { id: 'design', label: 'Design' },
    { id: 'development', label: 'Development' },
    { id: 'ux', label: 'UX Research' },
    { id: 'tips', label: 'Tips & Tricks' }
  ];
  
  const blogPosts = [
    {
      id: 1,
      title: "The Art of Minimalist Design",
      excerpt: "Exploring how less can truly be more in modern UI design. Discover key principles and techniques for creating impactful minimalist interfaces that focus on content and user experience.",
      date: "June 15, 2023",
      readTime: "5 min read",
      tags: ["design", "tips"],
      featured: true,
      image: "bg-gradient-blue"
    },
    {
      id: 2,
      title: "Building Smooth Animations with React",
      excerpt: "A practical guide to creating fluid, performant animations in React applications without sacrificing performance. Learn the best practices for implementing animations that enhance the user experience.",
      date: "May 22, 2023",
      readTime: "8 min read",
      tags: ["development", "tips"],
      featured: true,
      image: "bg-gradient-blue"
    },
    {
      id: 3,
      title: "User Research Methods That Actually Work",
      excerpt: "Cut through the noise and focus on research methods that deliver actionable insights for your design process. From interviews to usability testing, discover how to gather meaningful data efficiently.",
      date: "April 10, 2023",
      readTime: "6 min read",
      tags: ["ux"],
      featured: true,
      image: "bg-gradient-blue"
    },
    {
      id: 4,
      title: "Typography in Web Design: A Complete Guide",
      excerpt: "Everything you need to know about choosing and implementing typography in your web projects. Learn about font pairing, hierarchy, and responsive type to create readable and visually appealing designs.",
      date: "March 5, 2023",
      readTime: "10 min read",
      tags: ["design"],
      image: "bg-gradient-blue"
    },
    {
      id: 5,
      title: "State Management in React: Beyond Redux",
      excerpt: "Exploring modern alternatives to Redux for managing state in React applications. From Context API to Zustand and Jotai, discover the tools that might be a better fit for your next project.",
      date: "February 20, 2023",
      readTime: "7 min read",
      tags: ["development"],
      image: "bg-gradient-blue"
    },
    {
      id: 6,
      title: "Designing for Accessibility: Best Practices",
      excerpt: "How to ensure your designs are accessible to all users, regardless of ability. Learn practical techniques for creating inclusive interfaces that comply with WCAG guidelines without compromising aesthetics.",
      date: "January 15, 2023",
      readTime: "9 min read",
      tags: ["design", "ux"],
      image: "bg-gradient-blue"
    },
    {
      id: 7,
      title: "The Future of Mobile UX Design",
      excerpt: "Trends and predictions for the evolution of mobile user experience design in the coming years. From gestural interfaces to AI-powered personalization, explore what's next in mobile design.",
      date: "December 10, 2022",
      readTime: "6 min read",
      tags: ["design", "ux"],
      image: "bg-gradient-blue"
    },
    {
      id: 8,
      title: "Performance Optimization Techniques for Web Apps",
      excerpt: "Practical strategies to improve the speed and performance of your web applications. Learn how to identify bottlenecks, optimize rendering, and deliver a faster experience to your users.",
      date: "November 28, 2022",
      readTime: "8 min read",
      tags: ["development", "tips"],
      image: "bg-gradient-blue"
    }
  ];
  
  // Get featured posts
  const featuredPosts = blogPosts.filter(post => post.featured);
  
  // Filter blog posts when searchTerm or activeTag changes
  useEffect(() => {
    const filtered = blogPosts.filter(post => {
      const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTag = activeTag === 'all' || post.tags.includes(activeTag);
      
      return matchesSearch && matchesTag;
    });
    
    setFilteredPosts(filtered);
  }, [searchTerm, activeTag]);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-16">
      {/* Hero Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            className="text-center space-y-6 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-block">
              <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-2">
                <span className="text-muted-foreground">Blog</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Thoughts on <span className="text-primary">Design & Development</span>
            </h1>
            
            <p className="text-muted-foreground text-lg">
              Articles, tutorials, and insights about UX design, web development, and the creative process.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Featured Posts Section */}
      <section className="section-padding bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-12">
            <h2 className="text-3xl font-bold">Featured Posts</h2>
            <p className="text-muted-foreground max-w-2xl">
              Selected articles highlighting key insights and ideas.
            </p>
          </div>
          
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {featuredPosts.map((post) => (
              <motion.div 
                key={post.id} 
                className="rounded-2xl overflow-hidden bg-background shadow-soft hover:shadow-strong transition-all duration-500 group h-full flex flex-col"
                variants={itemVariants}
              >
                <div className={`h-40 ${post.image} relative overflow-hidden`}>
                  <div className="absolute top-4 left-4">
                    <span className="inline-block rounded-full bg-primary/90 backdrop-blur-sm text-white px-3 py-1 text-xs shadow-soft">
                      Featured
                    </span>
                  </div>
                </div>
                <div className="p-6 space-y-4 flex-grow flex flex-col">
                  <div className="flex justify-between items-center text-sm text-muted-foreground mb-2">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  
                  <h3 className="font-bold text-xl group-hover:text-primary transition-colors duration-300">
                    {post.title}
                  </h3>
                  
                  <p className="text-muted-foreground flex-grow">{post.excerpt}</p>
                  
                  <div className="pt-4 mt-auto">
                    <Link 
                      to={`/blog/${post.id}`} 
                      className="inline-flex items-center text-primary hover:underline transition-all"
                    >
                      <span>Read Article</span>
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* All Posts Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-8">
            <h2 className="text-3xl font-bold">All Articles</h2>
            <p className="text-muted-foreground max-w-2xl">
              Browse through all articles or filter by topics.
            </p>
          </div>
          
          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
            <div className="relative w-full md:w-72">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-muted-foreground" />
              </div>
              <input 
                type="text" 
                placeholder="Search articles..." 
                className="pl-10 pr-4 py-2 w-full rounded-full bg-secondary text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <button
                  key={tag.id}
                  onClick={() => setActiveTag(tag.id)}
                  className={`px-4 py-1 rounded-full transition-colors text-sm ${
                    activeTag === tag.id 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* Blog Posts Grid */}
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <motion.div 
                  key={post.id} 
                  className="rounded-2xl overflow-hidden bg-background shadow-soft hover:shadow-strong transition-all duration-500 flex flex-col md:flex-row h-full"
                  variants={itemVariants}
                >
                  <div className={`h-40 md:h-auto md:w-1/3 ${post.image} relative overflow-hidden`}></div>
                  <div className="p-6 md:w-2/3 space-y-4 flex flex-col">
                    <div className="flex justify-between items-center text-sm text-muted-foreground mb-1">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    
                    <h3 className="font-bold text-lg hover:text-primary transition-colors duration-300">
                      {post.title}
                    </h3>
                    
                    <p className="text-muted-foreground text-sm flex-grow">{post.excerpt}</p>
                    
                    <div className="flex flex-wrap gap-2 pt-2">
                      {post.tags.map((tag, index) => (
                        <span 
                          key={index} 
                          className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
                        >
                          <Tag className="h-3 w-3 mr-1" />
                          {tags.find(t => t.id === tag)?.label}
                        </span>
                      ))}
                    </div>
                    
                    <div className="pt-2 mt-auto">
                      <Link 
                        to={`/blog/${post.id}`} 
                        className="inline-flex items-center text-primary hover:underline transition-all text-sm"
                      >
                        <span>Read Article</span>
                        <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <h3 className="text-xl font-medium mb-2">No articles found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
                <button 
                  onClick={() => {
                    setSearchTerm('');
                    setActiveTag('all');
                  }}
                  className="mt-4 button-secondary"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </motion.div>
        </div>
      </section>
      
      {/* Newsletter Section */}
      <section className="section-padding bg-secondary/50">
        <div className="max-w-3xl mx-auto text-center">
          <div className="space-y-4 mb-8">
            <h2 className="text-3xl font-bold">Stay Updated</h2>
            <p className="text-muted-foreground">
              Subscribe to my newsletter to receive new articles and updates directly in your inbox.
            </p>
          </div>
          
          <form className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow px-4 py-2 rounded-full bg-background text-foreground border border-border focus:outline-none focus:ring-2 focus:ring-primary/50"
                required
              />
              <button 
                type="submit" 
                className="button-main whitespace-nowrap"
              >
                Subscribe
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              I respect your privacy. No spam, ever. Unsubscribe at any time.
            </p>
          </form>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;
