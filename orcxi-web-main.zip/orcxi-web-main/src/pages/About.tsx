import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Key, Briefcase, GraduationCap, Award, Mail } from 'lucide-react';
import Logo from '@/components/Logo';
import ServicesSection from '@/components/ServicesSection';

interface SocialLink {
  platform: string;
  url: string;
}

interface AboutInfo {
  name: string;
  title: string;
  bio: string;
  socialLinks: SocialLink[];
}

const defaultInfo: AboutInfo = {
  name: "Harsh Sharma",
  title: "CEO & Founder",
  bio: "With over 5 years of experience, I specialize in creating clean, functional websites and applications that focus on user experience and performance. I believe in designing with purpose and letting the content speak for itself.",
  socialLinks: []
};

const About = () => {
  const [aboutInfo, setAboutInfo] = useState<AboutInfo>(defaultInfo);

  useEffect(() => {
    const savedInfo = localStorage.getItem('orcxi-about-info');
    if (savedInfo) {
      setAboutInfo(JSON.parse(savedInfo));
    }
  }, []);
  
  return (
    <div className="min-h-screen pt-28 pb-16">
      {/* Hero Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="space-y-6">
                <div className="inline-block">
                  <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-6">
                    <span className="text-muted-foreground">About Me</span>
                  </div>
                </div>
                
                <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                  I'm {aboutInfo.name}, {aboutInfo.title} with a passion for <span className="text-primary">minimalist design</span>
                </h1>
                
                <p className="text-muted-foreground text-lg max-w-2xl">
                  {aboutInfo.bio}
                </p>
                
                <div className="flex flex-wrap gap-4 pt-4">
                  {aboutInfo.socialLinks.map((link, index) => (
                    <a 
                      key={index} 
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="button-secondary"
                    >
                      {link.platform}
                    </a>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="relative order-1 lg:order-2 flex justify-center">
              <div className="relative w-64 h-64 md:w-80 md:h-80">
                <div className="absolute top-0 left-0 h-full w-full bg-gradient-blue rounded-full opacity-10 blur-2xl animate-pulse"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-48 w-48 md:h-64 md:w-64 rounded-full bg-secondary overflow-hidden">
                  <Logo size="lg" className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Services Section */}
      <ServicesSection />

      {/* Core Values Section */}
      <section className="section-padding bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Core Values</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              The principles that guide our design and development process.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { 
                icon: Key, 
                title: "Simplicity", 
                description: "We believe in keeping designs clean and focused, eliminating unnecessary elements to highlight what truly matters."
              },
              { 
                icon: Award, 
                title: "Quality", 
                description: "Never compromising on quality, we ensure every project meets the highest standards of design and functionality."
              },
              { 
                icon: Briefcase, 
                title: "Reliability", 
                description: "Meeting deadlines and delivering consistent results are fundamental to how we approach every project."
              }
            ].map((item, index) => (
              <div key={index} className="bg-background rounded-2xl p-6 shadow-soft hover:shadow-strong transition-all duration-300">
                <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-bold text-xl mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Experience Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Professional Experience</h2>
            <p className="text-muted-foreground max-w-2xl">
              Over 5 years of experience working with agencies and clients on various digital projects.
            </p>
          </div>
          
          <div className="space-y-8">
            {[
              {
                role: "Senior UI/UX Designer",
                company: "Digital Waves Studio",
                period: "2021 - Present",
                description: "Leading the design team to create interfaces for web and mobile applications, focusing on user experience and accessibility.",
                achievements: [
                  "Redesigned the company's flagship product, increasing user engagement by 40%",
                  "Established a comprehensive design system for consistent branding",
                  "Mentored junior designers and implemented design thinking workshops"
                ]
              },
              {
                role: "Frontend Developer",
                company: "TechHub Solutions",
                period: "2019 - 2021",
                description: "Developed responsive websites and web applications using React, focusing on performance optimization and clean code principles.",
                achievements: [
                  "Built and maintained over 20 client websites with modern frameworks",
                  "Reduced loading times across projects by 35% through optimization",
                  "Collaborated with designers to improve the development workflow"
                ]
              },
              {
                role: "UI Designer",
                company: "Creative Minds Agency",
                period: "2017 - 2019",
                description: "Created user interfaces for websites and applications, working closely with clients to understand their needs and objectives.",
                achievements: [
                  "Designed interfaces for clients across various industries",
                  "Implemented user testing sessions to improve design decisions",
                  "Received agency's 'Designer of the Year' award in 2018"
                ]
              }
            ].map((experience, index) => (
              <div key={index} className="relative pl-8 border-l-2 border-border hover:border-primary transition-colors duration-300">
                <div className="absolute top-0 left-[-9px] h-4 w-4 rounded-full bg-primary"></div>
                <div className="pb-8">
                  <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-2">
                    <h3 className="font-bold text-xl">{experience.role}</h3>
                    <span className="text-sm text-muted-foreground">{experience.period}</span>
                  </div>
                  <div className="text-lg text-primary mb-2">{experience.company}</div>
                  <p className="text-muted-foreground mb-4">{experience.description}</p>
                  <ul className="space-y-2">
                    {experience.achievements.map((achievement, achievementIndex) => (
                      <li key={achievementIndex} className="flex items-baseline">
                        <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary"></span>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Education Section */}
      <section className="section-padding bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Education & Certifications</h2>
            <p className="text-muted-foreground max-w-2xl">
              Formal education and continued learning through specialized certifications.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-8">
              <h3 className="text-2xl font-bold flex items-center">
                <GraduationCap className="mr-2 h-6 w-6" />
                Education
              </h3>
              
              {[
                {
                  degree: "Master of Interaction Design",
                  institution: "Design Institute, San Francisco",
                  year: "2015 - 2017",
                  details: "Focused on user-centered design methodologies and interaction patterns for digital products."
                },
                {
                  degree: "Bachelor of Computer Science",
                  institution: "Tech University, Boston",
                  year: "2011 - 2015",
                  details: "Specialized in web development and user interface programming."
                }
              ].map((education, index) => (
                <div key={index} className="relative pl-8 border-l-2 border-border hover:border-primary transition-colors duration-300">
                  <div className="absolute top-0 left-[-9px] h-4 w-4 rounded-full bg-primary"></div>
                  <div className="pb-6">
                    <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-2">
                      <h4 className="font-bold text-lg">{education.degree}</h4>
                      <span className="text-sm text-muted-foreground">{education.year}</span>
                    </div>
                    <div className="text-primary mb-2">{education.institution}</div>
                    <p className="text-muted-foreground">{education.details}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="space-y-8">
              <h3 className="text-2xl font-bold flex items-center">
                <Award className="mr-2 h-6 w-6" />
                Certifications
              </h3>
              
              {[
                {
                  name: "Advanced User Experience Design",
                  issuer: "UX Design Institute",
                  year: "2020",
                  details: "Comprehensive training in advanced UX methodologies and research techniques."
                },
                {
                  name: "Frontend Web Development",
                  issuer: "Web Development Academy",
                  year: "2019",
                  details: "Specialized training in modern JavaScript frameworks and responsive design."
                },
                {
                  name: "UI Animation and Micro-interactions",
                  issuer: "Interactive Design Association",
                  year: "2018",
                  details: "Focused on creating meaningful animations that enhance user experience."
                }
              ].map((certification, index) => (
                <div key={index} className="bg-background rounded-lg p-4 shadow-soft hover:shadow-strong transition-all duration-300">
                  <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-2">
                    <h4 className="font-bold text-lg">{certification.name}</h4>
                    <span className="text-sm text-muted-foreground">{certification.year}</span>
                  </div>
                  <div className="text-primary mb-2">{certification.issuer}</div>
                  <p className="text-muted-foreground">{certification.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Skills Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-4 text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Skills & Expertise</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A comprehensive set of skills developed through years of practice and continuous learning.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-6 rounded-2xl bg-background p-6 shadow-soft">
              <h3 className="text-xl font-bold flex items-center">
                <BarChart className="mr-2 h-5 w-5 text-primary" />
                Design
              </h3>
              <div className="space-y-4">
                {["UI/UX Design", "Wireframing", "Prototyping", "User Research", "Visual Design", "Design Systems"].map((skill, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span>{skill}</span>
                    <div className="h-1.5 w-24 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${90 - index * 5}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-6 rounded-2xl bg-background p-6 shadow-soft">
              <h3 className="text-xl font-bold flex items-center">
                <Code className="mr-2 h-5 w-5 text-primary" />
                Development
              </h3>
              <div className="space-y-4">
                {["HTML/CSS", "JavaScript", "React", "TypeScript", "Responsive Design", "Performance Optimization"].map((skill, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span>{skill}</span>
                    <div className="h-1.5 w-24 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${95 - index * 8}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-6 rounded-2xl bg-background p-6 shadow-soft">
              <h3 className="text-xl font-bold flex items-center">
                <Globe className="mr-2 h-5 w-5 text-primary" />
                Tools
              </h3>
              <div className="space-y-4">
                {["Figma", "Adobe Creative Suite", "Sketch", "Git", "VS Code", "Notion"].map((skill, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span>{skill}</span>
                    <div className="h-1.5 w-24 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${85 - index * 5}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Contact CTA Section */}
      <section className="section-padding mt-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-secondary/70 rounded-2xl p-8 md:p-12 text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Interested in working together?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
              We're always open to discussing new projects, creative ideas or opportunities to be part of your vision.
            </p>
            <Link
              to="/contact"
              className="button-main"
            >
              <Mail className="mr-2 h-4 w-4" />
              <span>Get in Touch</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
