
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminBlogEditor from '@/components/AdminBlogEditor';
import AdminLayout from '@/components/AdminLayout';
import AdminPartnersEditor from '@/components/AdminPartnersEditor';
import AdminServicesEditor from '@/components/AdminServicesEditor';
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminDashboard from '@/components/AdminDashboard';
import AdminPrivacyEditor from '@/components/AdminPrivacyEditor';
import AdminTermsEditor from '@/components/AdminTermsEditor';
import AdminSubscribersViewer from '@/components/AdminSubscribersViewer';
import AdminSkillsEditor from '@/components/AdminSkillsEditor';
import AdminContactEditor from '@/components/AdminContactEditor';
import AdminOffersEditor from '@/components/AdminOffersEditor';

const Admin = () => {
  return (
    <Routes>
      <Route path="/" element={
        <ProtectedRoute>
          <AdminLayout title="Dashboard">
            <AdminDashboard />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/blog" element={
        <ProtectedRoute>
          <AdminLayout title="Blog Management">
            <AdminBlogEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/partners" element={
        <ProtectedRoute>
          <AdminLayout title="Partners Management">
            <AdminPartnersEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/services" element={
        <ProtectedRoute>
          <AdminLayout title="Services Management">
            <AdminServicesEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/privacy" element={
        <ProtectedRoute>
          <AdminLayout title="Privacy Policy Editor">
            <AdminPrivacyEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/terms" element={
        <ProtectedRoute>
          <AdminLayout title="Terms of Service Editor">
            <AdminTermsEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/skills" element={
        <ProtectedRoute>
          <AdminLayout title="Skills Management">
            <AdminSkillsEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/subscribers" element={
        <ProtectedRoute>
          <AdminLayout title="Email Subscribers">
            <AdminSubscribersViewer />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/contact" element={
        <ProtectedRoute>
          <AdminLayout title="Contact Information">
            <AdminContactEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      <Route path="/offers" element={
        <ProtectedRoute>
          <AdminLayout title="Orcxi Offers">
            <AdminOffersEditor />
          </AdminLayout>
        </ProtectedRoute>
      } />
      {/* Instead of showing a 404 page within admin, redirect to the dashboard */}
      <Route path="*" element={<Navigate to="/admin" replace />} />
    </Routes>
  );
};

export default Admin;
