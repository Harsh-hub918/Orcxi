
import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

type AuthContextType = {
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  isAuthenticating: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(true);
  const { toast } = useToast();

  // Check localStorage on initial load
  useEffect(() => {
    setIsAuthenticating(true);
    const adminStatus = localStorage.getItem('orcxi-admin');
    if (adminStatus === 'true') {
      setIsAdmin(true);
      toast({
        title: "Admin Access Granted",
        description: "You are now logged in as an admin.",
      });
    }
    setIsAuthenticating(false);
  }, [toast]);

  // The actual admin password should be securely stored in a backend
  // This is just a simple implementation for demonstration
  const adminPassword = 'orcxi-admin-2024';

  const login = (password: string): boolean => {
    if (password === adminPassword) {
      setIsAdmin(true);
      localStorage.setItem('orcxi-admin', 'true');
      toast({
        title: "Login Successful",
        description: "You now have admin privileges.",
      });
      return true;
    }
    toast({
      title: "Login Failed",
      description: "Incorrect password. Please try again.",
      variant: "destructive"
    });
    return false;
  };

  const logout = () => {
    setIsAdmin(false);
    localStorage.removeItem('orcxi-admin');
    toast({
      title: "Logged Out",
      description: "You have been logged out of admin mode.",
    });
  };

  return (
    <AuthContext.Provider value={{ isAdmin, login, logout, isAuthenticating }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
