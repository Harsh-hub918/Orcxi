
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Partner } from '@/models/Partner';
import { useAuth } from '@/contexts/AuthContext';
import { ExternalLink } from 'lucide-react';

const defaultPartners: Partner[] = [
  {
    id: 1,
    name: "TechCorp",
    logo: "/assets/partners/techcorp.png",
    website: "https://example.com"
  },
  {
    id: 2,
    name: "InnovatePro",
    logo: "/assets/partners/innovate.png",
    website: "https://example.com"
  },
  {
    id: 3,
    name: "DesignMasters",
    logo: "/assets/partners/designmasters.png",
    website: "https://example.com"
  },
  {
    id: 4,
    name: "CreativeStudio",
    logo: "/assets/partners/creativestudio.png",
    website: "https://example.com"
  },
  {
    id: 5,
    name: "WebSolutions",
    logo: "/assets/partners/websolutions.png",
    website: "https://example.com"
  }
];

const PartnersSection = () => {
  const [partners, setPartners] = useState<Partner[]>([]);
  const { isAdmin } = useAuth();
  
  useEffect(() => {
    // In a real app, you would fetch this from an API or database
    const savedPartners = localStorage.getItem('orcxi-partners');
    setPartners(savedPartners ? JSON.parse(savedPartners) : defaultPartners);
  }, []);
  
  // Function to handle image errors by replacing with a fallback
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const target = e.target as HTMLImageElement;
    const partner = partners.find(p => p.logo === target.src);
    target.src = `https://via.placeholder.com/150x50?text=${partner?.name || 'Partner'}`;
  };
  
  return (
    <section className="section-padding bg-secondary/50">
      <div className="max-w-7xl mx-auto">
        <div className="space-y-4 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Working With</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Proud to collaborate with these amazing brands and companies.
          </p>
        </div>
        
        <div className="relative overflow-hidden w-full py-8">
          <div className="marquee-container">
            <motion.div
              className="flex space-x-16"
              animate={{
                x: ["0%", "-100%"]
              }}
              transition={{
                x: {
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 180, // Slowed down even more from 120 to 180
                  ease: "linear"
                }
              }}
            >
              {[...partners, ...partners].map((partner, index) => (
                <AlertDialog key={index}>
                  <AlertDialogTrigger asChild>
                    <div className="flex-shrink-0 opacity-70 hover:opacity-100 transition-opacity cursor-pointer">
                      <img 
                        src={partner.logo} 
                        alt={partner.name} 
                        className="h-16 object-contain" 
                        onError={handleImageError}
                      />
                      <span className="sr-only">{partner.name}</span>
                    </div>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>{partner.name}</AlertDialogTitle>
                      <AlertDialogDescription className="space-y-4">
                        <div className="flex justify-center mb-4">
                          <img 
                            src={partner.logo} 
                            alt={partner.name} 
                            className="max-h-24 object-contain" 
                            onError={handleImageError}
                          />
                        </div>
                        
                        {partner.website && (
                          <div className="flex justify-center">
                            <a 
                              href={partner.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 text-blue-500 hover:underline"
                            >
                              Visit Website
                              <ExternalLink size={16} />
                            </a>
                          </div>
                        )}
                        
                        <p>Due to privacy agreements with our partners, we cannot share detailed information. Please contact us for more information about our partnerships.</p>
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogAction>Close</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnersSection;
