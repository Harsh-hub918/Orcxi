import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import supabase from '@/utils/supabaseClient';

const TermsOfServiceDisplay = () => {
  const [terms, setTerms] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTerms = async () => {
      try {
        // Try to get from Supabase first
        const { data, error } = await supabase
          .from('site_content')
          .select('content')
          .eq('name', 'terms_of_service')
          .single();
        
        if (error) throw error;
        
        if (data) {
          setTerms(data.content);
        } else {
          // Fallback to localStorage
          const localTerms = localStorage.getItem('orcxi-terms');
          if (localTerms) {
            setTerms(localTerms);
          } else {
            // Default content
            setTerms('# Terms of Service\n\nThese Terms of Service ("Terms") govern your use of the Orcxi website and services. By accessing or using our services, you agree to be bound by these Terms.');
          }
        }
      } catch (error) {
        console.error('Error fetching terms:', error);
        
        // Fallback to localStorage
        const localTerms = localStorage.getItem('orcxi-terms');
        if (localTerms) {
          setTerms(localTerms);
        } else {
          // Default content
          setTerms('# Terms of Service\n\nThese Terms of Service ("Terms") govern your use of the Orcxi website and services. By accessing or using our services, you agree to be bound by these Terms.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchTerms();
  }, []);
  
  // Simple markdown-like rendering
  const renderMarkdown = (text: string) => {
    // Replace headings
    let html = text.replace(/^# (.+)$/gm, '<h1 class="text-3xl font-bold mb-6">$1</h1>');
    html = html.replace(/^## (.+)$/gm, '<h2 class="text-2xl font-bold mt-8 mb-4">$1</h2>');
    html = html.replace(/^### (.+)$/gm, '<h3 class="text-xl font-bold mt-6 mb-3">$1</h3>');
    
    // Replace paragraphs
    html = html.replace(/^(?!<h[1-6]|<ul|<ol|<li|<blockquote)(.+)$/gm, '<p class="mb-4">$1</p>');
    
    // Replace line breaks
    html = html.replace(/\n\n/g, '<br>');
    
    // Handle lists (basic support)
    html = html.replace(/^- (.+)$/gm, '<li class="ml-6 list-disc mb-2">$1</li>');
    html = html.replace(/^(\d+)\. (.+)$/gm, '<li class="ml-6 list-decimal mb-2">$2</li>');
    
    // Wrap adjacent list items in ul/ol tags (simplified)
    html = html.replace(/(<li class="ml-6 list-disc mb-2">.*?<\/li>\n)+/gs, '<ul class="my-4">$&</ul>');
    html = html.replace(/(<li class="ml-6 list-decimal mb-2">.*?<\/li>\n)+/gs, '<ol class="my-4">$&</ol>');
    
    // Bold and italics
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    
    return html;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-16">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Card className="max-w-4xl mx-auto my-8">
      <CardContent className="pt-6">
        <div 
          className="prose max-w-none" 
          dangerouslySetInnerHTML={{ __html: renderMarkdown(terms) }} 
        />
      </CardContent>
    </Card>
  );
};

export default TermsOfServiceDisplay;
