
import { ExternalLink, Github, Link as LinkIcon } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from '@/components/Logo';

// Default project images based on category
const projectImages = {
  web: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y29kaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  mobile: "https://images.unsplash.com/photo-1555774698-0b77e0d5fac6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8bW9iaWxlJTIwYXBwfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  branding: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhbmRpbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
  design: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHVpJTIwZGVzaWdufGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  default: "https://images.unsplash.com/photo-1572177812156-58036aae439c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvamVjdHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60"
};

// Additional fallback images to ensure no empty cards
const fallbackImages = [
  "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y29kaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8ZGV2ZWxvcG1lbnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
  "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dGVjaHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
  "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Y29kaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
];

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  image?: string;
  category?: string;
  link?: string;
  github?: string;
  featured?: boolean;
}

const ProjectCard = ({
  title,
  description,
  tags,
  image,
  category = "default",
  link = "#",
  github,
  featured = false
}: ProjectCardProps) => {
  // Generate a consistent fallback image based on the project title
  const getFallbackImage = () => {
    // Simple hash function to get a consistent number from a string
    const hash = title.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const index = hash % fallbackImages.length;
    return fallbackImages[index];
  };
  
  // Determine which image to display with enhanced fallback logic
  const displayImage = image || 
                      projectImages[category as keyof typeof projectImages] || 
                      getFallbackImage() || 
                      projectImages.default;
  
  return (
    <Card className="overflow-hidden shadow-soft hover:shadow-strong transition-all duration-500 group h-full interactive">
      <div className="h-48 relative overflow-hidden">
        {displayImage ? (
          <img 
            src={displayImage} 
            alt={title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className={`h-full w-full bg-gradient-blue flex items-center justify-center`}>
            <Logo size="sm" />
          </div>
        )}
        {featured && (
          <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
            Featured
          </div>
        )}
      </div>
      <CardHeader className="p-4 pb-0">
        <div className="flex flex-wrap gap-2 mb-2">
          {tags.map((tag, tagIndex) => (
            <span 
              key={tagIndex} 
              className="inline-block rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
            >
              {tag}
            </span>
          ))}
        </div>
        <CardTitle className="text-xl group-hover:text-primary transition-colors duration-300">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <CardDescription className="text-muted-foreground">{description}</CardDescription>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <div className="flex space-x-4">
          <a 
            href={link} 
            className="inline-flex items-center text-primary hover:underline transition-all text-sm interactive"
            target="_blank"
            rel="noopener noreferrer"
          >
            <LinkIcon className="mr-1 h-4 w-4" />
            <span>Live Preview</span>
          </a>
          
          {github && (
            <a 
              href={github} 
              className="inline-flex items-center text-muted-foreground hover:text-primary transition-all text-sm interactive"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Github className="mr-1 h-4 w-4" />
              <span>Source Code</span>
            </a>
          )}
        </div>
      </CardFooter>
    </Card>
  );
};

export default ProjectCard;
