
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Trash2, Edit2, Save, UserPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Employee } from '@/models/Employee';

// Default team members
const defaultTeamMembers: Employee[] = [
  {
    id: 1,
    name: "Harsh Sharma",
    position: "CEO & Founder",
    bio: "Experienced leader with a passion for innovation and growth.",
    photo: "/assets/team/harsh.jpg",
    linkedin: "https://linkedin.com/",
    twitter: "https://twitter.com/",
    socialLinks: {
      linkedin: "https://linkedin.com/",
      twitter: "https://twitter.com/",
      github: "https://github.com/"
    }
  },
  {
    id: 2,
    name: "Jane Smith",
    position: "Lead Designer",
    bio: "Creative designer with 10+ years of experience in UI/UX and brand identity.",
    photo: "/assets/team/jane.jpg",
    linkedin: "https://linkedin.com/",
    twitter: "https://twitter.com/",
    socialLinks: {
      linkedin: "https://linkedin.com/",
      twitter: "https://twitter.com/"
    }
  },
  {
    id: 3,
    name: "Michael Brown",
    position: "Senior Developer",
    bio: "Full-stack developer specializing in React and Node.js applications.",
    photo: "/assets/team/michael.jpg",
    linkedin: "https://linkedin.com/",
    socialLinks: {
      linkedin: "https://linkedin.com/",
      github: "https://github.com/"
    }
  }
];

const AdminTeamEditor = () => {
  const [teamMembers, setTeamMembers] = useState<Employee[]>([]);
  const [editingMember, setEditingMember] = useState<Employee | null>(null);
  const [newMember, setNewMember] = useState<Partial<Employee>>({
    name: '',
    position: '',
    bio: '',
    photo: '',
    socialLinks: {
      linkedin: '',
      twitter: '',
      github: ''
    }
  });
  const { toast } = useToast();

  useEffect(() => {
    // In a real app, you would fetch this from an API
    const savedMembers = localStorage.getItem('orcxi-team');
    setTeamMembers(savedMembers ? JSON.parse(savedMembers) : defaultTeamMembers);
  }, []);

  const saveToLocalStorage = (members: Employee[]) => {
    localStorage.setItem('orcxi-team', JSON.stringify(members));
    setTeamMembers(members);
  };

  const handleAddMember = () => {
    if (!newMember.name || !newMember.position) {
      toast({
        title: "Missing information",
        description: "Please provide at least a name and position.",
        variant: "destructive"
      });
      return;
    }

    const newTeamMember: Employee = {
      id: Date.now(),
      name: newMember.name,
      position: newMember.position,
      bio: newMember.bio || '',
      photo: newMember.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(newMember.name)}`,
      linkedin: newMember.socialLinks?.linkedin || '',
      twitter: newMember.socialLinks?.twitter || '',
      socialLinks: {
        linkedin: newMember.socialLinks?.linkedin || '',
        twitter: newMember.socialLinks?.twitter || '',
        github: newMember.socialLinks?.github || ''
      }
    };

    const updatedMembers = [...teamMembers, newTeamMember];
    saveToLocalStorage(updatedMembers);
    
    toast({
      title: "Team member added",
      description: `${newMember.name} has been added to the team.`
    });

    // Reset the new member form
    setNewMember({
      name: '',
      position: '',
      bio: '',
      photo: '',
      socialLinks: {
        linkedin: '',
        twitter: '',
        github: ''
      }
    });
  };

  const handleEditMember = (member: Employee) => {
    setEditingMember(member);
  };

  const handleUpdateMember = () => {
    if (!editingMember) return;
    
    const updatedMembers = teamMembers.map(member => 
      member.id === editingMember.id ? editingMember : member
    );
    
    saveToLocalStorage(updatedMembers);
    
    toast({
      title: "Team member updated",
      description: `${editingMember.name}'s information has been updated.`
    });
    
    setEditingMember(null);
  };

  const handleDeleteMember = (id: number) => {
    const updatedMembers = teamMembers.filter(member => member.id !== id);
    saveToLocalStorage(updatedMembers);
    
    toast({
      title: "Team member removed",
      description: "The team member has been removed."
    });
  };

  const handleInputChange = (field: string, value: string) => {
    if (editingMember) {
      if (field.startsWith('socialLinks.')) {
        const socialField = field.split('.')[1];
        setEditingMember({
          ...editingMember,
          socialLinks: {
            ...editingMember.socialLinks,
            [socialField]: value
          }
        });
      } else {
        setEditingMember({
          ...editingMember,
          [field]: value
        });
      }
    }
  };

  const handleNewMemberChange = (field: string, value: string) => {
    if (field.startsWith('socialLinks.')) {
      const socialField = field.split('.')[1];
      setNewMember({
        ...newMember,
        socialLinks: {
          ...newMember.socialLinks,
          [socialField]: value
        }
      });
    } else {
      setNewMember({
        ...newMember,
        [field]: value
      });
    }
  };

  return (
    <Tabs defaultValue="team-list" className="space-y-6">
      <TabsList>
        <TabsTrigger value="team-list">Team List</TabsTrigger>
        <TabsTrigger value="add-member">Add Member</TabsTrigger>
      </TabsList>
      
      <TabsContent value="team-list" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Team Members</h2>
          <Button onClick={() => {
            const trigger = document.querySelector('[data-value="add-member"]');
            if (trigger) {
              (trigger as HTMLElement).click();
            }
          }}>
            <UserPlus className="mr-2 h-4 w-4" />
            Add New Member
          </Button>
        </div>
        
        {teamMembers.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-6">
                <p className="text-muted-foreground">No team members found. Add your first team member.</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {teamMembers.map((member) => (
              <Card key={member.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={member.photo} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{member.name}</CardTitle>
                        <CardDescription>{member.position}</CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <p className="text-sm text-muted-foreground line-clamp-3">{member.bio}</p>
                </CardContent>
                <CardFooter className="flex justify-between pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleEditMember(member)}
                  >
                    <Edit2 className="mr-1 h-4 w-4" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    onClick={() => handleDeleteMember(member.id)}
                  >
                    <Trash2 className="mr-1 h-4 w-4" />
                    Delete
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
        
        {/* Edit Dialog */}
        {editingMember && (
          <Card className="border-2 border-primary/50 shadow-lg mt-8">
            <CardHeader>
              <CardTitle>Edit Team Member</CardTitle>
              <CardDescription>Update information for {editingMember.name}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Name</Label>
                  <Input 
                    id="edit-name" 
                    value={editingMember.name} 
                    onChange={(e) => handleInputChange('name', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-position">Position</Label>
                  <Input 
                    id="edit-position" 
                    value={editingMember.position} 
                    onChange={(e) => handleInputChange('position', e.target.value)} 
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-photo">Profile Image URL</Label>
                <Input 
                  id="edit-photo" 
                  value={editingMember.photo} 
                  onChange={(e) => handleInputChange('photo', e.target.value)} 
                  placeholder="https://example.com/image.jpg"
                />
                <p className="text-xs text-muted-foreground">
                  Leave empty to use a generated avatar based on name
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-bio">Bio</Label>
                <Textarea 
                  id="edit-bio" 
                  value={editingMember.bio} 
                  onChange={(e) => handleInputChange('bio', e.target.value)} 
                  rows={3} 
                />
              </div>
              
              <div className="space-y-4">
                <Label>Social Links</Label>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="edit-linkedin">LinkedIn</Label>
                    <Input 
                      id="edit-linkedin" 
                      value={editingMember.socialLinks?.linkedin || ''} 
                      onChange={(e) => handleInputChange('socialLinks.linkedin', e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-twitter">Twitter</Label>
                    <Input 
                      id="edit-twitter" 
                      value={editingMember.socialLinks?.twitter || ''} 
                      onChange={(e) => handleInputChange('socialLinks.twitter', e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-github">GitHub</Label>
                    <Input 
                      id="edit-github" 
                      value={editingMember.socialLinks?.github || ''} 
                      onChange={(e) => handleInputChange('socialLinks.github', e.target.value)} 
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setEditingMember(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateMember}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        )}
      </TabsContent>
      
      <TabsContent value="add-member">
        <Card>
          <CardHeader>
            <CardTitle>Add New Team Member</CardTitle>
            <CardDescription>
              Create a new team member profile
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="new-name">Name *</Label>
                <Input 
                  id="new-name" 
                  value={newMember.name} 
                  onChange={(e) => handleNewMemberChange('name', e.target.value)} 
                  placeholder="John Doe"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-position">Position *</Label>
                <Input 
                  id="new-position" 
                  value={newMember.position} 
                  onChange={(e) => handleNewMemberChange('position', e.target.value)} 
                  placeholder="Software Developer"
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="new-photo">Profile Image URL</Label>
              <Input 
                id="new-photo" 
                value={newMember.photo} 
                onChange={(e) => handleNewMemberChange('photo', e.target.value)} 
                placeholder="https://example.com/image.jpg"
              />
              <p className="text-xs text-muted-foreground">
                Leave empty to use a generated avatar based on name
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="new-bio">Bio</Label>
              <Textarea 
                id="new-bio" 
                value={newMember.bio} 
                onChange={(e) => handleNewMemberChange('bio', e.target.value)} 
                rows={3} 
                placeholder="Brief description about this team member..."
              />
            </div>
            
            <div className="space-y-4">
              <Label>Social Links</Label>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="new-linkedin">LinkedIn</Label>
                  <Input 
                    id="new-linkedin" 
                    value={newMember.socialLinks?.linkedin} 
                    onChange={(e) => handleNewMemberChange('socialLinks.linkedin', e.target.value)} 
                    placeholder="https://linkedin.com/in/username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-twitter">Twitter</Label>
                  <Input 
                    id="new-twitter" 
                    value={newMember.socialLinks?.twitter} 
                    onChange={(e) => handleNewMemberChange('socialLinks.twitter', e.target.value)} 
                    placeholder="https://twitter.com/username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-github">GitHub</Label>
                  <Input 
                    id="new-github" 
                    value={newMember.socialLinks?.github} 
                    onChange={(e) => handleNewMemberChange('socialLinks.github', e.target.value)} 
                    placeholder="https://github.com/username"
                  />
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleAddMember} className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Add Team Member
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default AdminTeamEditor;
