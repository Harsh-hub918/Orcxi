
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isClicking, setIsClicking] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      setIsVisible(true);
    };

    const handleMouseOver = (e: MouseEvent) => {
      if (e.target instanceof HTMLElement) {
        // Check if hovering over interactive elements
        const isInteractive = 
          e.target.tagName === 'BUTTON' ||
          e.target.tagName === 'A' ||
          e.target.closest('button') ||
          e.target.closest('a') ||
          e.target.classList.contains('interactive') ||
          e.target.closest('.interactive');
        
        setIsHovering(!!isInteractive);
      } else {
        setIsHovering(false);
      }
    };

    const handleMouseDown = () => {
      setIsClicking(true);
    };

    const handleMouseUp = () => {
      setIsClicking(false);
    };

    const handleMouseEnter = () => {
      document.body.style.cursor = 'none';
      setIsVisible(true);
    };

    const handleMouseLeave = () => {
      setIsHovering(false);
      setIsClicking(false);
      setIsVisible(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseover', handleMouseOver);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('mouseleave', handleMouseLeave);
    
    // Hide default cursor
    document.documentElement.style.cursor = 'none';
    document.body.style.cursor = 'none';
    
    // Set cursor to visible on initial load
    setIsVisible(true);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('mouseleave', handleMouseLeave);
      
      // Restore default cursor when component unmounts
      document.documentElement.style.cursor = '';
      document.body.style.cursor = '';
    };
  }, []);

  // Only render if cursor is visible
  if (!isVisible) return null;

  return (
    <>
      {/* Primary cursor dot */}
      <motion.div 
        className="fixed pointer-events-none z-50 rounded-full"
        style={{
          width: isClicking ? '16px' : '20px',
          height: isClicking ? '16px' : '20px',
          left: position.x,
          top: position.y,
          transform: 'translate(-50%, -50%)',
          opacity: 1,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          mixBlendMode: 'difference',
          boxShadow: '0 0 10px rgba(255, 255, 255, 0.5), 0 0 5px rgba(0, 0, 0, 0.3)',
          border: '2px solid rgba(255, 255, 255, 0.8)',
        }}
        animate={{
          scale: isClicking ? 0.8 : 1,
          opacity: 1
        }}
        initial={{ scale: 0.5, opacity: 0 }}
        transition={{ 
          type: 'spring', 
          stiffness: 300, 
          damping: 20 
        }}
      />
      
      {/* Enhanced cursor ring for interactive elements */}
      {isHovering && (
        <motion.div 
          className="fixed pointer-events-none z-50 rounded-full"
          style={{
            width: '50px',
            height: '50px',
            left: position.x,
            top: position.y,
            transform: 'translate(-50%, -50%)',
            border: '2px solid rgba(255, 255, 255, 0.8)',
            backgroundColor: 'transparent',
            boxShadow: '0 0 15px rgba(255, 255, 255, 0.3)',
          }}
          animate={{
            scale: isClicking ? 0.9 : 1.1,
            opacity: 0.9
          }}
          initial={{ scale: 0.5, opacity: 0 }}
          transition={{ 
            type: 'spring', 
            stiffness: 300, 
            damping: 20 
          }}
        />
      )}
    </>
  );
};

export default CustomCursor;
