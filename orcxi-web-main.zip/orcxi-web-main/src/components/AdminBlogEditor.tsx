
import { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Save, X, Image, Tag as TagIcon, Upload, File, Plus } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  readTime: string;
  tags: string[];
  featured: boolean;
  image: string;
  images: string[]; // Array to store multiple images
}

const AdminBlogEditor = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const contentInputRef = useRef<HTMLTextAreaElement>(null);
  
  const [blogPost, setBlogPost] = useState<BlogPost>({
    id: Date.now(),
    title: '',
    excerpt: '',
    content: '',
    date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
    readTime: '5 min read',
    tags: [],
    featured: false,
    image: '',
    images: []
  });
  const [tagInput, setTagInput] = useState('');
  const [showImageGallery, setShowImageGallery] = useState(false);

  // Redirect if not admin
  useEffect(() => {
    if (!isAdmin) {
      toast({
        title: "Access Denied",
        description: "Only admin users can access this feature.",
        variant: "destructive"
      });
      navigate('/');
    }
  }, [isAdmin, navigate, toast]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setBlogPost(prev => ({ ...prev, [name]: value }));
  };

  const handleTagAdd = () => {
    if (tagInput.trim()) {
      setBlogPost(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const handleTagRemove = (tagToRemove: string) => {
    setBlogPost(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleFeaturedToggle = () => {
    setBlogPost(prev => ({ ...prev, featured: !prev.featured }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = () => {
        if (reader.result) {
          const imageUrl = reader.result.toString();
          setBlogPost(prev => ({ 
            ...prev, 
            images: [...prev.images, imageUrl],
            image: prev.image || imageUrl // Set as main image if none exists
          }));
          
          toast({
            title: "Image Uploaded",
            description: "Image has been added to your blog post."
          });
        }
      };
      
      reader.readAsDataURL(file);
    }
  };
  
  const handleInsertImage = (imageUrl: string) => {
    if (contentInputRef.current) {
      const startPos = contentInputRef.current.selectionStart;
      const endPos = contentInputRef.current.selectionEnd;
      const currentContent = blogPost.content;
      const imageTag = `\n![Image](${imageUrl})\n`;
      
      const newContent = 
        currentContent.substring(0, startPos) + 
        imageTag + 
        currentContent.substring(endPos);
      
      setBlogPost(prev => ({ ...prev, content: newContent }));
      
      // After update, set cursor position after the inserted image tag
      setTimeout(() => {
        if (contentInputRef.current) {
          const newCursorPosition = startPos + imageTag.length;
          contentInputRef.current.focus();
          contentInputRef.current.setSelectionRange(newCursorPosition, newCursorPosition);
        }
      }, 0);
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setBlogPost(prev => ({
      ...prev,
      images: prev.images.filter((_, index) => index !== indexToRemove),
      // If the main image is being removed, reset it
      image: prev.image === prev.images[indexToRemove] ? '' : prev.image
    }));
  };

  const handleSetMainImage = (imageUrl: string) => {
    setBlogPost(prev => ({ ...prev, image: imageUrl }));
    toast({
      title: "Main Image Set",
      description: "This image will be used as the blog post thumbnail."
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to a database
    console.log('Saving blog post:', blogPost);
    
    toast({
      title: "Blog Post Saved",
      description: "Your blog post has been saved successfully."
    });
    
    // Reset form or redirect
    setBlogPost({
      id: Date.now(),
      title: '',
      excerpt: '',
      content: '',
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      readTime: '5 min read',
      tags: [],
      featured: false,
      image: '',
      images: []
    });
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Create New Blog Post</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Blog Title</Label>
            <Input
              id="title"
              name="title"
              value={blogPost.title}
              onChange={handleInputChange}
              placeholder="Enter blog title"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="excerpt">Excerpt</Label>
            <Textarea
              id="excerpt"
              name="excerpt"
              value={blogPost.excerpt}
              onChange={handleInputChange}
              placeholder="Enter a short excerpt of your blog post"
              required
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="content">Content</Label>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={() => setShowImageGallery(!showImageGallery)}
                className="flex items-center gap-1.5"
              >
                <Image className="h-4 w-4" />
                <span>Image Gallery</span>
              </Button>
            </div>
            
            {showImageGallery && (
              <div className="border rounded-md p-4 mb-4 bg-background/50">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium">Available Images</h3>
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1.5"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Upload New</span>
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                </div>
                
                {blogPost.images.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <File className="h-16 w-16 mx-auto mb-2 opacity-50" />
                    <p>No images uploaded yet</p>
                    <p className="text-sm">Click "Upload New" to add images</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {blogPost.images.map((img, idx) => (
                      <div 
                        key={idx} 
                        className={`relative rounded-md overflow-hidden border-2 ${
                          img === blogPost.image ? 'border-primary' : 'border-transparent'
                        } group`}
                      >
                        <img 
                          src={img} 
                          alt={`Blog image ${idx + 1}`} 
                          className="w-full h-24 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8 text-white" 
                            onClick={() => handleInsertImage(img)}
                            title="Insert image at cursor position"
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8 text-white"
                            onClick={() => handleSetMainImage(img)}
                            title="Set as main image"
                          >
                            <Image className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8 text-white"
                            onClick={() => handleRemoveImage(idx)}
                            title="Remove image"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            
            <Textarea
              id="content"
              name="content"
              value={blogPost.content}
              onChange={handleInputChange}
              placeholder="Write your blog content here. You can insert images from the gallery."
              rows={10}
              required
              ref={contentInputRef}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="readTime">Read Time</Label>
              <Select 
                onValueChange={(value) => setBlogPost(prev => ({ ...prev, readTime: value }))}
                value={blogPost.readTime}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select read time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3 min read">3 min read</SelectItem>
                  <SelectItem value="5 min read">5 min read</SelectItem>
                  <SelectItem value="8 min read">8 min read</SelectItem>
                  <SelectItem value="10 min read">10 min read</SelectItem>
                  <SelectItem value="15 min read">15 min read</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="featured">Featured</Label>
              <div className="flex items-center space-x-2 pt-2">
                <input 
                  type="checkbox" 
                  id="featured"
                  checked={blogPost.featured}
                  onChange={handleFeaturedToggle}
                  className="h-4 w-4"
                />
                <label htmlFor="featured" className="text-sm">Mark as featured post</label>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="image">Main Image</Label>
            <div className="flex gap-2">
              <Input
                id="image"
                name="image"
                value={blogPost.image}
                onChange={handleInputChange}
                placeholder="Enter image URL or select from gallery"
                className="flex-grow"
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5"
              >
                <Upload className="h-4 w-4" />
                <span>Upload</span>
              </Button>
            </div>
            
            {blogPost.image && (
              <div className="mt-2 border rounded-md p-2 inline-block">
                <img 
                  src={blogPost.image} 
                  alt="Main blog image" 
                  className="h-24 object-cover rounded" 
                />
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add a tag"
                className="rounded-r-none"
              />
              <Button 
                type="button" 
                onClick={handleTagAdd}
                className="rounded-l-none"
              >
                Add
              </Button>
            </div>
            
            <div className="flex flex-wrap gap-2 mt-2">
              {blogPost.tags.map((tag, index) => (
                <div 
                  key={index}
                  className="bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-sm flex items-center gap-1"
                >
                  <TagIcon className="h-3 w-3" />
                  <span>{tag}</span>
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer hover:text-primary"
                    onClick={() => handleTagRemove(tag)}
                  />
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => navigate('/admin')}
            >
              Cancel
            </Button>
            <Button type="submit">Save Blog Post</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default AdminBlogEditor;
