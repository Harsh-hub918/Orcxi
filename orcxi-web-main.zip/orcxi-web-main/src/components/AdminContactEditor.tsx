import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import supabase from '@/utils/supabaseClient';

interface ContactInfo {
  email: string;
  phone: string;
  address: string;
}

const defaultContactInfo: ContactInfo = {
  email: "info@orcxi.com",
  phone: "+1 (555) 123-4567",
  address: "123 Business Ave, Tech City, CA 94101"
};

const AdminContactEditor = () => {
  const [contactInfo, setContactInfo] = useState<ContactInfo>(defaultContactInfo);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchContactInfo = async () => {
      try {
        const { data, error } = await supabase
          .from('site_content')
          .select('content')
          .eq('name', 'contact_info')
          .single();

        if (error) throw error;

        if (data && data.content) {
          setContactInfo(JSON.parse(data.content));
        } else {
          const savedInfo = localStorage.getItem('orcxi-contact-info');
          if (savedInfo) {
            setContactInfo(JSON.parse(savedInfo));
          }
        }
      } catch (error) {
        console.error("Error fetching contact info:", error);
        
        const savedInfo = localStorage.getItem('orcxi-contact-info');
        if (savedInfo) {
          try {
            setContactInfo(JSON.parse(savedInfo));
          } catch (parseError) {
            console.error("Error parsing contact info:", parseError);
          }
        }
      }
    };

    fetchContactInfo();
  }, []);

  const handleInputChange = (field: keyof ContactInfo, value: string) => {
    setContactInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const saveContactInfo = async () => {
    setIsSaving(true);
    
    try {
      const { error } = await supabase
        .from('site_content')
        .upsert({
          name: 'contact_info',
          content: JSON.stringify(contactInfo),
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      localStorage.setItem('orcxi-contact-info', JSON.stringify(contactInfo));
      
      toast({
        title: "Contact Information Saved",
        description: "Your contact details have been updated successfully.",
      });
    } catch (error) {
      console.error("Error saving contact info:", error);
      toast({
        title: "Error Saving",
        description: "There was a problem saving your contact information.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Contact Information</CardTitle>
        <CardDescription>
          Update your contact details displayed on the website
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            value={contactInfo.email}
            onChange={(e) => handleInputChange("email", e.target.value)}
            placeholder="contact@example.com"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            type="tel"
            value={contactInfo.phone}
            onChange={(e) => handleInputChange("phone", e.target.value)}
            placeholder="+1 (555) 123-4567"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="address">Address</Label>
          <Input
            id="address"
            value={contactInfo.address}
            onChange={(e) => handleInputChange("address", e.target.value)}
            placeholder="123 Business St, City, State 12345"
          />
        </div>
        
        <Button 
          onClick={saveContactInfo} 
          disabled={isSaving}
          className="mt-4"
        >
          {isSaving ? "Saving..." : "Save Contact Information"}
        </Button>
      </CardContent>
    </Card>
  );
};

export default AdminContactEditor;
