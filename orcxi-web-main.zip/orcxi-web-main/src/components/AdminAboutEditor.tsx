
import { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save, Trash2, Plus, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from "@/integrations/supabase/client";

interface SocialLink {
  platform: string;
  url: string;
}

interface AboutInfo {
  name: string;
  title: string;
  bio: string;
  socialLinks: SocialLink[];
  profileImage?: string;
}

const defaultInfo: AboutInfo = {
  name: "Harsh Sharma",
  title: "CEO & Founder",
  bio: "With over 5 years of experience, I specialize in creating clean, functional websites and applications that focus on user experience and performance. I believe in designing with purpose and letting the content speak for itself.",
  socialLinks: []
};

const AdminAboutEditor = () => {
  const [aboutInfo, setAboutInfo] = useState<AboutInfo>(defaultInfo);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // First try to fetch from Supabase, then fallback to localStorage
    const fetchAboutInfo = async () => {
      try {
        const { data, error } = await supabase
          .from('about_info')
          .select('*')
          .single();
        
        if (error) {
          console.log('No data in Supabase, trying localStorage:', error);
          const savedInfo = localStorage.getItem('orcxi-about-info');
          if (savedInfo) {
            setAboutInfo(JSON.parse(savedInfo));
          }
        } else if (data) {
          console.log('Loaded data from Supabase:', data);
          setAboutInfo(data.info);
        }
      } catch (error) {
        console.error('Error fetching about info:', error);
        // Fallback to localStorage
        const savedInfo = localStorage.getItem('orcxi-about-info');
        if (savedInfo) {
          setAboutInfo(JSON.parse(savedInfo));
        }
      }
    };

    fetchAboutInfo();
  }, []);

  const handleSaveInfo = async () => {
    setLoading(true);
    try {
      // First, check if record exists
      const { data } = await supabase
        .from('about_info')
        .select('id')
        .single();
      
      if (data) {
        // Update existing record
        const { error } = await supabase
          .from('about_info')
          .update({ info: aboutInfo })
          .eq('id', data.id);
        
        if (error) throw error;
      } else {
        // Insert new record
        const { error } = await supabase
          .from('about_info')
          .insert([{ info: aboutInfo }]);
        
        if (error) throw error;
      }

      // Also update localStorage as fallback
      localStorage.setItem('orcxi-about-info', JSON.stringify(aboutInfo));
      
      toast({
        title: "About Information Updated",
        description: "Your changes have been saved successfully to Supabase."
      });
    } catch (error) {
      console.error('Error saving about info:', error);
      
      // Fallback to localStorage
      localStorage.setItem('orcxi-about-info', JSON.stringify(aboutInfo));
      
      toast({
        title: "Saved to Local Storage",
        description: "Could not save to database, but saved locally.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: keyof AboutInfo, value: string) => {
    setAboutInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addSocialLink = () => {
    setAboutInfo(prev => ({
      ...prev,
      socialLinks: [...prev.socialLinks, { platform: '', url: '' }]
    }));
  };

  const updateSocialLink = (index: number, field: keyof SocialLink, value: string) => {
    const newSocialLinks = [...aboutInfo.socialLinks];
    newSocialLinks[index] = {
      ...newSocialLinks[index],
      [field]: value
    };
    setAboutInfo(prev => ({
      ...prev,
      socialLinks: newSocialLinks
    }));
  };

  const removeSocialLink = (index: number) => {
    const newSocialLinks = aboutInfo.socialLinks.filter((_, i) => i !== index);
    setAboutInfo(prev => ({
      ...prev,
      socialLinks: newSocialLinks
    }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      return;
    }
    
    const file = e.target.files[0];
    const fileExt = file.name.split('.').pop();
    const fileName = `profile-${Date.now()}.${fileExt}`;
    
    setLoading(true);
    
    try {
      // Upload image to Supabase storage
      const { data, error } = await supabase.storage
        .from('admin_images')
        .upload(fileName, file);
      
      if (error) {
        throw error;
      }
      
      // Get public URL for the uploaded image
      const { data: { publicUrl } } = supabase.storage
        .from('admin_images')
        .getPublicUrl(fileName);
      
      // Update the aboutInfo state with the image URL
      setAboutInfo(prev => ({
        ...prev,
        profileImage: publicUrl
      }));
      
      toast({
        title: "Image Uploaded",
        description: "Profile image has been uploaded successfully."
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>About Page Information</CardTitle>
          <CardDescription>
            Edit your personal information displayed on the About page
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="profileImage">Profile Image</Label>
            <div className="flex items-center gap-4">
              {aboutInfo.profileImage && (
                <div className="relative h-20 w-20 rounded-full overflow-hidden border">
                  <img 
                    src={aboutInfo.profileImage} 
                    alt="Profile" 
                    className="h-full w-full object-cover"
                  />
                </div>
              )}
              <div className="flex-1">
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={loading}
                  className="w-full"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {aboutInfo.profileImage ? 'Change Profile Image' : 'Upload Profile Image'}
                </Button>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input 
              id="name" 
              value={aboutInfo.name}
              onChange={(e) => handleChange('name', e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="title">Title/Position</Label>
            <Input 
              id="title" 
              value={aboutInfo.title}
              onChange={(e) => handleChange('title', e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea 
              id="bio" 
              value={aboutInfo.bio}
              onChange={(e) => handleChange('bio', e.target.value)} 
              rows={5}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleSaveInfo} 
            className="ml-auto"
            disabled={loading}
          >
            {loading ? 'Saving...' : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Social Links</CardTitle>
          <CardDescription>
            Add and manage your social media links
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {aboutInfo.socialLinks.map((link, index) => (
            <div key={index} className="flex space-x-4">
              <div className="flex-grow space-y-2">
                <Label htmlFor={`platform-${index}`}>Platform</Label>
                <Input 
                  id={`platform-${index}`}
                  value={link.platform}
                  onChange={(e) => updateSocialLink(index, 'platform', e.target.value)}
                  placeholder="e.g., LinkedIn"
                />
              </div>
              <div className="flex-grow space-y-2">
                <Label htmlFor={`url-${index}`}>URL</Label>
                <Input 
                  id={`url-${index}`}
                  value={link.url}
                  onChange={(e) => updateSocialLink(index, 'url', e.target.value)}
                  placeholder="https://www.example.com/profile"
                />
              </div>
              <div className="flex items-end">
                <Button 
                  variant="destructive" 
                  size="icon" 
                  onClick={() => removeSocialLink(index)}
                  className="ml-2"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          
          <Button 
            variant="outline" 
            onClick={addSocialLink}
            className="w-full mt-4"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Social Link
          </Button>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleSaveInfo} 
            className="ml-auto"
            disabled={loading}
          >
            {loading ? 'Saving...' : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Preview</CardTitle>
          <CardDescription>
            How your information will appear on the About page
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md p-6 bg-background/50">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              {aboutInfo.profileImage && (
                <div className="h-32 w-32 rounded-full overflow-hidden flex-shrink-0">
                  <img 
                    src={aboutInfo.profileImage} 
                    alt={aboutInfo.name} 
                    className="h-full w-full object-cover"
                  />
                </div>
              )}
              <div>
                <h1 className="text-2xl font-bold mb-2">
                  I'm {aboutInfo.name}, {aboutInfo.title} with a passion for <span className="text-primary">minimalist design</span>
                </h1>
                <p className="text-muted-foreground">
                  {aboutInfo.bio}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminAboutEditor;
