import { useCallback, useState } from "react";
import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Shield } from "lucide-react";
import { getContactInfo } from "@/utils/contactInfoUtils";
import PrivacyPolicyPopup from "./PrivacyPolicyPopup";
import { useAuth } from "@/contexts/AuthContext";

const Footer = () => {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const contactInfo = getContactInfo();
  const { isAdmin } = useAuth();

  const togglePrivacyPolicy = useCallback(() => {
    setShowPrivacyPolicy(prev => !prev);
  }, []);

  return (
    <footer className="bg-card text-card-foreground border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <a href={`mailto:${contactInfo.email}`} className="hover:underline">
                  {contactInfo.email}
                </a>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <a href={`tel:${contactInfo.phone}`} className="hover:underline">
                  {contactInfo.phone}
                </a>
              </div>
              <div className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5" />
                <span>{contactInfo.address}</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <nav className="space-y-2">
              <div><Link to="/" className="hover:underline">Home</Link></div>
              <div><Link to="/about" className="hover:underline">About</Link></div>
              <div><Link to="/projects" className="hover:underline">Projects</Link></div>
              <div><Link to="/blog" className="hover:underline">Blog</Link></div>
              <div><Link to="/contact" className="hover:underline">Contact</Link></div>
            </nav>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <div className="space-y-2">
              <div>
                <button 
                  onClick={togglePrivacyPolicy}
                  className="hover:underline text-left"
                >
                  Privacy Policy
                </button>
              </div>
              <div><Link to="/terms" className="hover:underline">Terms of Service</Link></div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center">
            © {new Date().getFullYear()} Orcxi. All rights reserved.
            <Link 
              to="/admin" 
              className="ml-4 flex items-center text-muted-foreground hover:text-primary transition-colors"
            >
              <Shield className="h-3.5 w-3.5 mr-1" />
              Admin
            </Link>
            {isAdmin && (
              <Link 
                to="/login" 
                className="ml-4 text-muted-foreground hover:text-primary transition-colors"
              >
                Logout
              </Link>
            )}
          </p>
        </div>
      </div>
      
      <PrivacyPolicyPopup 
        open={showPrivacyPolicy} 
        onClose={togglePrivacyPolicy} 
      />
    </footer>
  );
};

export default Footer;
