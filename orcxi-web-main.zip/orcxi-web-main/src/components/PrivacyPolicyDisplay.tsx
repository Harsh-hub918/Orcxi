
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

const PrivacyPolicyDisplay = () => {
  const [policy, setPolicy] = useState({
    title: "",
    content: "",
    lastUpdated: ""
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch privacy policy from localStorage
    const fetchPolicy = () => {
      setLoading(true);
      try {
        const savedPolicy = localStorage.getItem('orcxi-privacy-policy');
        if (savedPolicy) {
          setPolicy(JSON.parse(savedPolicy));
        } else {
          setPolicy({
            title: "Privacy Policy",
            content: "No privacy policy has been set yet. Please check back later.",
            lastUpdated: new Date().toISOString().split('T')[0]
          });
        }
      } catch (error) {
        console.error("Error loading privacy policy:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPolicy();
  }, []);

  const renderContent = () => {
    if (loading) {
      return (
        <div className="space-y-4">
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-full" />
        </div>
      );
    }

    return (
      <div className="prose prose-sm max-w-none dark:prose-invert">
        <h1>{policy.title}</h1>
        <p className="text-muted-foreground text-sm">Last updated: {policy.lastUpdated}</p>
        <div
          dangerouslySetInnerHTML={{
            __html: policy.content
              .replace(/^# (.*$)/gm, '<h1>$1</h1>')
              .replace(/^## (.*$)/gm, '<h2>$1</h2>')
              .replace(/^### (.*$)/gm, '<h3>$1</h3>')
              .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
              .replace(/\*(.*?)\*/g, '<em>$1</em>')
              .replace(/\n- /g, '<br>• ')
              .replace(/\n/g, '<br>')
          }}
        />
      </div>
    );
  };

  return (
    <div className="bg-card border rounded-lg shadow-md p-6 mt-4">
      <ScrollArea className="h-[60vh]">
        {renderContent()}
      </ScrollArea>
    </div>
  );
};

export default PrivacyPolicyDisplay;
