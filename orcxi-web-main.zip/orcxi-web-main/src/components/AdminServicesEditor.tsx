
import { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Edit2, Save, FileText, Upload, Image } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Service } from '@/models/Service';

const defaultServices: Service[] = [
  {
    id: 1,
    title: "Web Development",
    description: "Custom websites and web applications with responsive design",
    icon: "code",
    image: "https://via.placeholder.com/640x360?text=Web+Development",
    features: ["Responsive Design", "SEO Optimization", "CMS Integration"]
  },
  {
    id: 2,
    title: "UI/UX Design",
    description: "User-centered design that enhances engagement and conversion",
    icon: "layout",
    image: "https://via.placeholder.com/640x360?text=UI/UX+Design",
    features: ["User Research", "Wireframing", "Prototyping"]
  },
  {
    id: 3,
    title: "Business Consulting",
    description: "Strategic guidance for digital transformation and growth",
    icon: "briefcase",
    image: "https://via.placeholder.com/640x360?text=Business+Consulting",
    features: ["Growth Strategy", "Process Optimization", "Market Analysis"]
  }
];

const AdminServicesEditor = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [newService, setNewService] = useState<Partial<Service>>({
    title: '',
    description: '',
    image: '',
    features: []
  });
  const [newFeature, setNewFeature] = useState('');
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // In a real app, you would fetch this from an API
    const savedServices = localStorage.getItem('orcxi-services');
    setServices(savedServices ? JSON.parse(savedServices) : defaultServices);
  }, []);

  const saveToLocalStorage = (updatedServices: Service[]) => {
    localStorage.setItem('orcxi-services', JSON.stringify(updatedServices));
    setServices(updatedServices);
  };

  const handleAddService = () => {
    if (!newService.title || !newService.description) {
      toast({
        title: "Missing information",
        description: "Please provide at least a title and description.",
        variant: "destructive"
      });
      return;
    }

    const newServiceItem: Service = {
      id: Date.now(),
      title: newService.title,
      description: newService.description,
      image: newService.image || `https://via.placeholder.com/640x360?text=${encodeURIComponent(newService.title)}`,
      features: newService.features || []
    };

    const updatedServices = [...services, newServiceItem];
    saveToLocalStorage(updatedServices);
    
    toast({
      title: "Service added",
      description: `${newService.title} has been added to services.`
    });

    // Reset the new service form
    setNewService({
      title: '',
      description: '',
      image: '',
      features: []
    });
  };

  const handleEditService = (service: Service) => {
    setEditingService({...service});
  };

  const handleUpdateService = () => {
    if (!editingService) return;
    
    const updatedServices = services.map(service => 
      service.id === editingService.id ? editingService : service
    );
    
    saveToLocalStorage(updatedServices);
    
    toast({
      title: "Service updated",
      description: `${editingService.title} has been updated.`
    });
    
    setEditingService(null);
  };

  const handleDeleteService = (id: number) => {
    const updatedServices = services.filter(service => service.id !== id);
    saveToLocalStorage(updatedServices);
    
    toast({
      title: "Service removed",
      description: "The service has been removed."
    });
  };

  const handleAddFeature = () => {
    if (!newFeature) return;
    
    if (editingService) {
      const features = [...(editingService.features || []), newFeature];
      setEditingService({...editingService, features});
    } else {
      const features = [...(newService.features || []), newFeature];
      setNewService({...newService, features});
    }
    
    setNewFeature('');
  };

  const handleRemoveFeature = (index: number) => {
    if (editingService) {
      const features = [...(editingService.features || [])];
      features.splice(index, 1);
      setEditingService({...editingService, features});
    } else {
      const features = [...(newService.features || [])];
      features.splice(index, 1);
      setNewService({...newService, features});
    }
  };

  const handleInputChange = (field: string, value: string) => {
    if (editingService) {
      setEditingService({...editingService, [field]: value});
    }
  };

  const handleNewServiceChange = (field: string, value: string) => {
    setNewService({...newService, [field]: value});
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>, isEditing: boolean) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      
      if (isEditing && editingService) {
        setEditingService({...editingService, image: base64String});
      } else {
        setNewService({...newService, image: base64String});
      }

      toast({
        title: "Image uploaded",
        description: "Your image has been added successfully."
      });
    };

    reader.readAsDataURL(file);
  };

  return (
    <Tabs defaultValue="services-list" className="space-y-6">
      <TabsList>
        <TabsTrigger value="services-list">Services List</TabsTrigger>
        <TabsTrigger value="add-service">Add Service</TabsTrigger>
      </TabsList>
      
      <TabsContent value="services-list" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Services</h2>
          <Button onClick={() => {
            const trigger = document.querySelector('[data-value="add-service"]');
            if (trigger) {
              (trigger as HTMLElement).click();
            }
          }}>
            <Plus className="mr-2 h-4 w-4" />
            Add New Service
          </Button>
        </div>
        
        {services.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-6">
                <p className="text-muted-foreground">No services found. Add your first service.</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card key={service.id} className="overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="aspect-video w-full overflow-hidden bg-muted">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  {service.features && service.features.length > 0 && (
                    <div className="mt-2">
                      <h4 className="text-sm font-medium mb-1">Features:</h4>
                      <ul className="list-disc pl-5 text-sm text-muted-foreground">
                        {service.features.map((feature, idx) => (
                          <li key={idx}>{feature}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleEditService(service)}
                  >
                    <Edit2 className="mr-1 h-4 w-4" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    onClick={() => handleDeleteService(service.id)}
                  >
                    <Trash2 className="mr-1 h-4 w-4" />
                    Delete
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
        
        {/* Edit Dialog */}
        {editingService && (
          <Card className="border-2 border-primary/50 shadow-lg mt-8">
            <CardHeader>
              <CardTitle>Edit Service</CardTitle>
              <CardDescription>Update information for {editingService.title}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-title">Title</Label>
                  <Input 
                    id="edit-title" 
                    value={editingService.title} 
                    onChange={(e) => handleInputChange('title', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea 
                    id="edit-description" 
                    value={editingService.description} 
                    onChange={(e) => handleInputChange('description', e.target.value)} 
                    rows={3}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-image">Image</Label>
                <div className="flex flex-col gap-3">
                  <div className="flex gap-2">
                    <Input 
                      id="edit-image" 
                      value={editingService.image?.startsWith('data:') ? 'Local Image Uploaded' : editingService.image} 
                      onChange={(e) => handleInputChange('image', e.target.value)} 
                      placeholder="https://example.com/image.jpg"
                      className="flex-1"
                      readOnly={editingService.image?.startsWith('data:')}
                    />
                    <input 
                      type="file" 
                      ref={editFileInputRef} 
                      className="hidden" 
                      accept="image/*" 
                      onChange={(e) => handleImageUpload(e, true)}
                    />
                    <Button 
                      type="button" 
                      variant="secondary" 
                      onClick={() => editFileInputRef.current?.click()}
                      className="flex-shrink-0"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Image
                    </Button>
                  </div>
                  {editingService.image && (
                    <div className="rounded-md overflow-hidden border bg-muted/20 p-2">
                      <img 
                        src={editingService.image} 
                        alt="Preview" 
                        className="h-40 object-contain mx-auto"
                      />
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Features</Label>
                <div className="space-y-2">
                  {editingService.features && editingService.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input value={feature} readOnly />
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleRemoveFeature(index)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex items-center gap-2">
                    <Input 
                      value={newFeature}
                      onChange={(e) => setNewFeature(e.target.value)}
                      placeholder="Add a new feature"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddFeature();
                        }
                      }}
                    />
                    <Button onClick={handleAddFeature}>Add</Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setEditingService(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateService}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        )}
      </TabsContent>
      
      <TabsContent value="add-service">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Add New Service</CardTitle>
            <CardDescription>
              Create a new service offering
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-title">Title *</Label>
              <Input 
                id="new-title" 
                value={newService.title} 
                onChange={(e) => handleNewServiceChange('title', e.target.value)} 
                placeholder="Web Development"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="new-description">Description *</Label>
              <Textarea 
                id="new-description" 
                value={newService.description} 
                onChange={(e) => handleNewServiceChange('description', e.target.value)} 
                rows={3} 
                placeholder="Describe the service offering..."
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="new-image">Image</Label>
              <div className="flex flex-col gap-3">
                <div className="flex gap-2">
                  <Input 
                    id="new-image" 
                    value={newService.image?.startsWith('data:') ? 'Local Image Uploaded' : newService.image} 
                    onChange={(e) => handleNewServiceChange('image', e.target.value)} 
                    placeholder="https://example.com/image.jpg"
                    className="flex-1"
                    readOnly={newService.image?.startsWith('data:')}
                  />
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={(e) => handleImageUpload(e, false)}
                  />
                  <Button 
                    type="button" 
                    variant="secondary" 
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Image className="h-4 w-4 mr-2" />
                    Upload Image
                  </Button>
                </div>
                {newService.image && (
                  <div className="rounded-md overflow-hidden border bg-muted/20 p-2">
                    <img 
                      src={newService.image} 
                      alt="Preview" 
                      className="h-40 object-contain mx-auto"
                    />
                  </div>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Upload a local image or provide an image URL
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Features</Label>
              <div className="space-y-2">
                {newService.features && newService.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input value={feature} readOnly />
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleRemoveFeature(index)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
                <div className="flex items-center gap-2">
                  <Input 
                    value={newFeature}
                    onChange={(e) => setNewFeature(e.target.value)}
                    placeholder="Add a new feature"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddFeature();
                      }
                    }}
                  />
                  <Button onClick={handleAddFeature}>Add</Button>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleAddService} className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Add Service
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default AdminServicesEditor;
