import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trash2, RefreshCw, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import supabase from '@/utils/supabaseClient';

interface Subscriber {
  id: string;
  email: string;
  created_at: string;
  name?: string;
}

const AdminSubscribersViewer = () => {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const { toast } = useToast();
  
  // Fetch subscribers from Supabase
  useEffect(() => {
    const fetchSubscribers = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('subscribers')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        setSubscribers(data || []);
      } catch (error) {
        console.error('Error fetching subscribers:', error);
        toast({
          title: "Error fetching subscribers",
          description: "Could not load subscriber data from the database.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchSubscribers();
  }, [refreshKey, toast]);
  
  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };
  
  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('subscribers')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      // Update the local state
      setSubscribers(subscribers.filter(sub => sub.id !== id));
      
      toast({
        title: "Subscriber deleted",
        description: "The subscriber has been removed from your database."
      });
    } catch (error) {
      console.error('Error deleting subscriber:', error);
      toast({
        title: "Error deleting subscriber",
        description: "There was a problem deleting the subscriber. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleExportCSV = () => {
    try {
      // Format subscriber data for CSV
      const header = ['Email', 'Name', 'Date Subscribed'];
      const csvData = subscribers.map(sub => [
        sub.email,
        sub.name || '',
        new Date(sub.created_at).toLocaleDateString()
      ]);
      
      // Create CSV content
      const csvContent = [
        header.join(','),
        ...csvData.map(row => row.join(','))
      ].join('\n');
      
      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `subscribers-${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export successful",
        description: "Subscribers data has been exported to CSV."
      });
    } catch (error) {
      console.error('Error exporting subscribers:', error);
      toast({
        title: "Export failed",
        description: "There was a problem exporting the data. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Email Subscribers</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleRefresh} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-1 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportCSV} disabled={subscribers.length === 0}>
              <Download className="h-4 w-4 mr-1" />
              Export CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-primary border-t-transparent"></div>
              <p className="mt-2 text-sm text-muted-foreground">Loading subscribers...</p>
            </div>
          ) : subscribers.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No subscribers found. Start collecting emails on your website!</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {subscribers.map((subscriber) => (
                  <TableRow key={subscriber.id}>
                    <TableCell className="font-medium">{subscriber.email}</TableCell>
                    <TableCell>{subscriber.name || '-'}</TableCell>
                    <TableCell>{new Date(subscriber.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={() => handleDelete(subscriber.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSubscribersViewer;
