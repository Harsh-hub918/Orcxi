
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';
import { Service } from '@/models/Service';
import { Link } from 'react-router-dom';

const defaultServices: Service[] = [
  {
    id: 1,
    title: "Web Development",
    description: "Custom websites and web applications with responsive design",
    icon: "code",
    image: "https://via.placeholder.com/640x360?text=Web+Development",
    features: ["Responsive Design", "SEO Optimization", "CMS Integration"]
  },
  {
    id: 2,
    title: "UI/UX Design",
    description: "User-centered design that enhances engagement and conversion",
    icon: "layout",
    image: "https://via.placeholder.com/640x360?text=UI/UX+Design",
    features: ["User Research", "Wireframing", "Prototyping"]
  },
  {
    id: 3,
    title: "Business Consulting",
    description: "Strategic guidance for digital transformation and growth",
    icon: "briefcase",
    image: "https://via.placeholder.com/640x360?text=Business+Consulting",
    features: ["Growth Strategy", "Process Optimization", "Market Analysis"]
  }
];

const ServicesSection = () => {
  const [services, setServices] = useState<Service[]>([]);
  
  useEffect(() => {
    const savedServices = localStorage.getItem('orcxi-services');
    setServices(savedServices ? JSON.parse(savedServices) : defaultServices);
  }, []);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };
  
  return (
    <section className="section-padding bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="space-y-4 text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Our Services
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Professional solutions to help your business grow and succeed
          </motion.p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {services.map((service) => (
            <motion.div key={service.id} variants={itemVariants}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full flex flex-col">
                <div className="aspect-[16/9] overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <CardContent className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm mb-6 flex-grow">{service.description}</p>
                  
                  {service.features && service.features.length > 0 && (
                    <div className="mb-6">
                      <h4 className="font-semibold text-sm mb-2">Key Features:</h4>
                      <ul className="space-y-1">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-baseline text-sm">
                            <span className="mr-2 h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0"></span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <Button variant="outline" className="w-full mt-auto group">
                    <span>Learn More</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
        
        <div className="mt-12 text-center">
          <Link to="/contact">
            <Button size="lg">
              Request Custom Solution 
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
