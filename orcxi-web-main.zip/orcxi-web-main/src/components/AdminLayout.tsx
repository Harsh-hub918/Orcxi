
import { ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface AdminLayoutProps {
  children: ReactNode;
  title: string;
}

const AdminLayout = ({ children, title }: AdminLayoutProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout } = useAuth();
  const { toast } = useToast();

  const menuItems = [
    { name: 'Dashboard', path: '/admin' },
    { name: 'Blog Posts', path: '/admin/blog' },
    { name: 'Services', path: '/admin/services' },
    { name: 'Partners', path: '/admin/partners' },
    { name: 'Privacy Policy', path: '/admin/privacy' },
    { name: 'Terms of Service', path: '/admin/terms' },
    { name: 'Skills', path: '/admin/skills' },
    { name: 'Subscribers', path: '/admin/subscribers' },
    { name: 'Contact Info', path: '/admin/contact' },
    { name: 'Orcxi Offers', path: '/admin/offers' },
  ];

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out."
    });
    navigate('/login');
  };

  // Get the current active tab value based on the path
  const getCurrentTabValue = () => {
    const currentPath = location.pathname;
    const matchingItem = menuItems.find(item => 
      currentPath === item.path || 
      (item.path !== '/admin' && currentPath.startsWith(item.path))
    );
    return matchingItem ? matchingItem.path : '/admin';
  };

  return (
    <div className="min-h-screen bg-muted/10 pb-6">
      {/* Header with tabs navigation */}
      <header className="bg-card border-b shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
            <Button 
              variant="destructive" 
              size="sm"
              onClick={handleLogout}
              className="ml-auto"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
          
          <div className="relative">
            <Tabs 
              value={getCurrentTabValue()} 
              onValueChange={(value) => navigate(value)}
              className="w-full"
            >
              <div className="overflow-x-auto scrollbar-hide pb-1">
                <TabsList className="w-max min-w-full justify-start bg-background/80 backdrop-blur-sm">
                  {menuItems.map((item) => (
                    <TabsTrigger 
                      key={item.name} 
                      value={item.path}
                      className="px-4 py-2 whitespace-nowrap text-sm font-medium"
                    >
                      {item.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>
            </Tabs>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 py-6">
        {children}
      </main>
    </div>
  );
};

export default AdminLayout;
