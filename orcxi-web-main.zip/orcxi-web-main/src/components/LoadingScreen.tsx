
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader } from 'lucide-react';
import Logo from '@/components/Logo';

const LoadingScreen: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500); // Reduced from 6000ms to 2500ms for faster loading

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence mode="wait">
      {isLoading && (
        <motion.div
          className="fixed inset-0 bg-background/90 dark:bg-background/95 flex flex-col items-center justify-center z-[9999]"
          initial={{ opacity: 1 }}
          exit={{ 
            opacity: 0,
            transition: { duration: 0.3, ease: "easeInOut" } // Faster exit animation
          }}
        >
          <motion.div
            className="flex flex-col items-center"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }} // Faster initial animation
          >
            <Logo size="lg" className="h-24 w-24 mb-6" /> {/* Smaller logo */}
            
            <div className="relative">
              <motion.div
                className="w-48 h-1 bg-muted rounded-full overflow-hidden"
                initial={{ width: 0 }}
                animate={{ width: "12rem" }}
                transition={{ duration: 0.3 }}
              >
                <motion.div
                  className="h-full bg-primary"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2.2, ease: "easeInOut" }} // Faster progress animation
                />
              </motion.div>
              
              <div className="mt-4 flex items-center justify-center gap-2">
                <Loader className="h-4 w-4 animate-spin text-primary" />
                <span className="text-sm text-muted-foreground">Loading...</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
