import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import supabase from '@/utils/supabaseClient';

interface OfferItem {
  id: string;
  title: string;
  description: string;
  icon?: string;
}

const AdminOffersEditor = () => {
  const [offerItems, setOfferItems] = useState<OfferItem[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadOffers = async () => {
      try {
        const { data, error } = await supabase
          .from('site_content')
          .select('content')
          .eq('name', 'offers')
          .single();

        if (error) throw error;

        if (data && data.content) {
          setOfferItems(JSON.parse(data.content));
        } else {
          const savedOffers = localStorage.getItem('orcxi-offers');
          if (savedOffers) {
            setOfferItems(JSON.parse(savedOffers));
          } else {
            setOfferItems([
              {
                id: "1",
                title: "Web Development",
                description: "Custom websites built to engage visitors and drive business growth."
              },
              {
                id: "2",
                title: "SEO Services",
                description: "Improve your search rankings and increase organic traffic."
              },
              {
                id: "3",
                title: "Ad Management",
                description: "Strategic digital advertising to reach your target audience."
              }
            ]);
          }
        }
      } catch (error) {
        console.error("Error loading offer items:", error);
        
        const savedOffers = localStorage.getItem('orcxi-offers');
        if (savedOffers) {
          try {
            setOfferItems(JSON.parse(savedOffers));
          } catch (parseError) {
            console.error("Error parsing offers:", parseError);
          }
        }
      }
    };

    loadOffers();
  }, [toast]);

  const addOfferItem = () => {
    const newItem: OfferItem = {
      id: Date.now().toString(),
      title: "New Offer",
      description: "Description for the new offer."
    };
    
    setOfferItems([...offerItems, newItem]);
  };

  const removeOfferItem = (id: string) => {
    setOfferItems(offerItems.filter(item => item.id !== id));
  };

  const updateOfferItem = (id: string, field: keyof OfferItem, value: string) => {
    setOfferItems(offerItems.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const saveOffers = async () => {
    setIsSaving(true);
    
    try {
      const { error } = await supabase
        .from('site_content')
        .upsert({
          name: 'offers',
          content: JSON.stringify(offerItems),
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      localStorage.setItem('orcxi-offers', JSON.stringify(offerItems));
      
      toast({
        title: "Offers Saved",
        description: "Your offer items have been updated successfully.",
      });
    } catch (error) {
      console.error("Error saving offers:", error);
      toast({
        title: "Error Saving",
        description: "There was a problem saving your offer items.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage "What Orcxi Offers" Section</CardTitle>
        <CardDescription>
          Add, edit, or remove items shown in the "What Orcxi Offers" section on the homepage
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {offerItems.map((item, index) => (
          <div key={item.id} className="space-y-4">
            {index > 0 && <Separator className="my-4" />}
            
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Offer #{index + 1}</h3>
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={() => removeOfferItem(item.id)}
              >
                <Trash className="h-4 w-4 mr-2" />
                Remove
              </Button>
            </div>
            
            <div className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor={`title-${item.id}`}>Title</Label>
                <Input
                  id={`title-${item.id}`}
                  value={item.title}
                  onChange={(e) => updateOfferItem(item.id, "title", e.target.value)}
                  placeholder="Offer title"
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor={`desc-${item.id}`}>Description</Label>
                <Textarea
                  id={`desc-${item.id}`}
                  value={item.description}
                  onChange={(e) => updateOfferItem(item.id, "description", e.target.value)}
                  placeholder="Offer description"
                  rows={3}
                />
              </div>
            </div>
          </div>
        ))}
        
        <div className="flex justify-between mt-6">
          <Button 
            variant="outline" 
            onClick={addOfferItem}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New Offer
          </Button>
          
          <Button 
            onClick={saveOffers} 
            disabled={isSaving}
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminOffersEditor;
