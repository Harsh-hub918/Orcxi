
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PrivacyPolicy {
  title: string;
  content: string;
  lastUpdated: string;
}

const defaultPolicy: PrivacyPolicy = {
  title: "Privacy Policy",
  content: `# Privacy Policy for Orcxi

## 1. Introduction
At Orcxi, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.

## 2. Information We Collect
We may collect personal identification information including but not limited to:
- Name
- Email address
- Phone number
- Company information
- Information provided through contact forms

## 3. How We Use Your Information
We use the information we collect in various ways, including to:
- Provide, operate, and maintain our website
- Improve, personalize, and expand our website
- Understand and analyze how you use our website
- Develop new products, services, features, and functionality
- Communicate with you, either directly or through one of our partners
- Send you emails
- Find and prevent fraud

## 4. Third-Party Disclosure
We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties.

## 5. Data Security
We implement security measures to maintain the safety of your personal information.

## 6. Your Rights
If you are a resident of the European Economic Area (EEA), you have certain data protection rights under GDPR.

## 7. Changes to This Privacy Policy
We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.

## 8. Contact Us
If you have any questions about this Privacy Policy, please contact us.`,
  lastUpdated: new Date().toISOString().split('T')[0]
};

const AdminPrivacyEditor = () => {
  const [policy, setPolicy] = useState<PrivacyPolicy>(defaultPolicy);
  const { toast } = useToast();

  useEffect(() => {
    // In a real app, you would fetch this from an API
    const savedPolicy = localStorage.getItem('orcxi-privacy-policy');
    if (savedPolicy) {
      setPolicy(JSON.parse(savedPolicy));
    }
  }, []);

  const handleSavePolicy = () => {
    const updatedPolicy = {
      ...policy,
      lastUpdated: new Date().toISOString().split('T')[0]
    };
    
    localStorage.setItem('orcxi-privacy-policy', JSON.stringify(updatedPolicy));
    setPolicy(updatedPolicy);
    
    toast({
      title: "Privacy Policy Updated",
      description: "Your changes have been saved successfully."
    });
  };

  const handleChange = (field: keyof PrivacyPolicy, value: string) => {
    setPolicy(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Privacy Policy Editor</CardTitle>
          <CardDescription>
            Edit your website's privacy policy. Use Markdown for formatting.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="policy-title">Policy Title</Label>
            <Input 
              id="policy-title" 
              value={policy.title}
              onChange={(e) => handleChange('title', e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="policy-content">Policy Content (Markdown)</Label>
              <span className="text-xs text-muted-foreground">
                Last updated: {policy.lastUpdated}
              </span>
            </div>
            <Textarea 
              id="policy-content" 
              value={policy.content}
              onChange={(e) => handleChange('content', e.target.value)} 
              rows={20}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Use Markdown formatting for headings, lists, and other text styling.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSavePolicy} className="ml-auto">
            <Save className="mr-2 h-4 w-4" />
            Save Changes
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Preview</CardTitle>
          <CardDescription>
            How your privacy policy will appear to users
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <h1>{policy.title}</h1>
            <div dangerouslySetInnerHTML={{ 
              __html: policy.content
                .replace(/^# (.*$)/gm, '<h1>$1</h1>')
                .replace(/^## (.*$)/gm, '<h2>$1</h2>')
                .replace(/^### (.*$)/gm, '<h3>$1</h3>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/\n- /g, '<br>• ')
                .replace(/\n/g, '<br>')
            }} />
            <p><em>Last updated: {policy.lastUpdated}</em></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPrivacyEditor;
