
import { useState } from 'react';
import { Camera, Check, X, Phone } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface PersonalInfoProps {
  className?: string;
}

const PersonalInfo = ({ className }: PersonalInfoProps) => {
  const [name, setName] = useState('Harsh Sharma');
  const [editing, setEditing] = useState(false);
  const [tempName, setTempName] = useState(name);
  const [avatarUrl, setAvatarUrl] = useState('');
  const [showAvatarInput, setShowAvatarInput] = useState(false);
  const [tempAvatarUrl, setTempAvatarUrl] = useState(avatarUrl);

  const handleNameEdit = () => {
    setTempName(name);
    setEditing(true);
  };

  const saveName = () => {
    if (tempName.trim()) {
      setName(tempName);
    }
    setEditing(false);
  };

  const cancelNameEdit = () => {
    setEditing(false);
  };

  const handleAvatarEdit = () => {
    setTempAvatarUrl(avatarUrl);
    setShowAvatarInput(true);
  };

  const saveAvatar = () => {
    setAvatarUrl(tempAvatarUrl);
    setShowAvatarInput(false);
  };

  const cancelAvatarEdit = () => {
    setShowAvatarInput(false);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <div className={className}>
      <div className="flex flex-col items-center space-y-4">
        <div className="relative group">
          <Avatar className="h-24 w-24 md:h-32 md:w-32 border-2 border-primary/20">
            <AvatarImage src={avatarUrl} alt={name} />
            <AvatarFallback className="text-xl md:text-2xl bg-primary/10 text-primary">
              {getInitials(name)}
            </AvatarFallback>
          </Avatar>
          <button 
            onClick={handleAvatarEdit}
            className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            aria-label="Edit avatar"
          >
            <Camera className="h-4 w-4" />
          </button>
        </div>

        {showAvatarInput ? (
          <div className="flex flex-col space-y-2 w-full max-w-xs">
            <Input
              value={tempAvatarUrl}
              onChange={(e) => setTempAvatarUrl(e.target.value)}
              placeholder="Enter image URL"
              className="text-center"
            />
            <div className="flex justify-center gap-2">
              <Button size="sm" onClick={saveAvatar}>
                <Check className="h-4 w-4 mr-1" /> Save
              </Button>
              <Button size="sm" variant="outline" onClick={cancelAvatarEdit}>
                <X className="h-4 w-4 mr-1" /> Cancel
              </Button>
            </div>
          </div>
        ) : null}

        {editing ? (
          <div className="flex flex-col space-y-2 w-full max-w-xs">
            <Input
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              className="text-center font-bold text-xl"
            />
            <div className="flex justify-center gap-2">
              <Button size="sm" onClick={saveName}>
                <Check className="h-4 w-4 mr-1" /> Save
              </Button>
              <Button size="sm" variant="outline" onClick={cancelNameEdit}>
                <X className="h-4 w-4 mr-1" /> Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="group relative inline-block">
            <h2 className="text-2xl md:text-3xl font-bold">{name}</h2>
            <p className="text-sm text-muted-foreground mb-2">Pune, Maharashtra, India</p>
            <p className="text-sm flex items-center justify-center gap-1">
              <Phone className="h-3 w-3" /> 
              <span>WhatsApp Business: +91 83903 39245</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalInfo;
