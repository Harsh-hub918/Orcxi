
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface PrivacyPolicy {
  title: string;
  content: string;
  lastUpdated: string;
}

const defaultPolicy: PrivacyPolicy = {
  title: "Privacy Policy",
  content: "Loading privacy policy...",
  lastUpdated: new Date().toISOString().split('T')[0]
};

interface PrivacyPolicyPopupProps {
  open: boolean;
  onClose: () => void;
}

const PrivacyPolicyPopup = ({ open, onClose }: PrivacyPolicyPopupProps) => {
  const [policy, setPolicy] = useState<PrivacyPolicy>(defaultPolicy);

  useEffect(() => {
    if (open) {
      const savedPolicy = localStorage.getItem('orcxi-privacy-policy');
      setPolicy(savedPolicy ? JSON.parse(savedPolicy) : defaultPolicy);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle>{policy.title}</DialogTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <DialogDescription>Last updated: {policy.lastUpdated}</DialogDescription>
        </DialogHeader>
        <div className="prose prose-sm max-w-none dark:prose-invert mt-4">
          <div dangerouslySetInnerHTML={{ 
            __html: policy.content
              .replace(/^# (.*$)/gm, '<h1>$1</h1>')
              .replace(/^## (.*$)/gm, '<h2>$1</h2>')
              .replace(/^### (.*$)/gm, '<h3>$1</h3>')
              .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
              .replace(/\*(.*?)\*/g, '<em>$1</em>')
              .replace(/\n- /g, '<br>• ')
              .replace(/\n/g, '<br>')
          }} />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PrivacyPolicyPopup;
