
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface OfferItem {
  id: string;
  title: string;
  description: string;
  icon?: string;
}

const OrcxiOffersSection = () => {
  const [offerItems, setOfferItems] = useState<OfferItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load offer items from localStorage
    const loadOffers = () => {
      setLoading(true);
      try {
        const savedOffers = localStorage.getItem('orcxi-offers');
        if (savedOffers) {
          setOfferItems(JSON.parse(savedOffers));
        } else {
          // Default offers if none saved
          setOfferItems([
            {
              id: "1",
              title: "Web Development",
              description: "Custom websites built to engage visitors and drive business growth."
            },
            {
              id: "2",
              title: "SEO Services",
              description: "Improve your search rankings and increase organic traffic."
            },
            {
              id: "3",
              title: "Ad Management",
              description: "Strategic digital advertising to reach your target audience."
            }
          ]);
        }
      } catch (error) {
        console.error("Error loading offer items:", error);
      } finally {
        setLoading(false);
      }
    };

    loadOffers();
  }, []);

  if (loading) {
    return <div className="py-12 text-center">Loading offers...</div>;
  }

  return (
    <section className="py-12 bg-muted/50" id="offers">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-4">What Orcxi Offers</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital solutions to help your business thrive in the digital landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offerItems.map((offer) => (
            <Card key={offer.id} className="h-full">
              <CardHeader>
                <CardTitle>{offer.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-foreground/80">
                  {offer.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OrcxiOffersSection;
