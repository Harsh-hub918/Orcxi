
import { useState, useEffect, useRef } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Trash2, Edit, ExternalLink, Upload, LinkIcon } from 'lucide-react';
import { Partner } from '@/models/Partner';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Switch } from '@/components/ui/switch';

const defaultPartners: Partner[] = [
  {
    id: 1,
    name: "TechCorp",
    logo: "/assets/partners/techcorp.png",
    website: "https://example.com"
  },
  {
    id: 2,
    name: "InnovatePro",
    logo: "/assets/partners/innovate.png",
    website: "https://example.com"
  },
  {
    id: 3,
    name: "DesignMasters",
    logo: "/assets/partners/designmasters.png",
    website: "https://example.com"
  },
  {
    id: 4,
    name: "CreativeStudio",
    logo: "/assets/partners/creativestudio.png",
    website: "https://example.com"
  },
  {
    id: 5,
    name: "WebSolutions",
    logo: "/assets/partners/websolutions.png",
    website: "https://example.com"
  }
];

const AdminPartnersEditor = () => {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  const [newPartner, setNewPartner] = useState<Partial<Partner>>({
    name: '',
    logo: '',
    website: '',
    useLocalImage: false,
  });
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Load partners from localStorage or use defaults
    const savedPartners = localStorage.getItem('orcxi-partners');
    setPartners(savedPartners ? JSON.parse(savedPartners) : defaultPartners);
  }, []);

  const savePartners = (updatedPartners: Partner[]) => {
    localStorage.setItem('orcxi-partners', JSON.stringify(updatedPartners));
    setPartners(updatedPartners);
  };

  const handleFileUpload = async (file: File, isEditing: boolean = false) => {
    try {
      // Generate a unique file name
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `partners/${fileName}`;
      
      // Upload file to Supabase
      const { data, error } = await supabase.storage
        .from('admin_images')
        .upload(filePath, file);
      
      if (error) throw error;
      
      // Get public URL
      const { data: publicUrlData } = supabase.storage
        .from('admin_images')
        .getPublicUrl(filePath);
        
      const publicUrl = publicUrlData.publicUrl;
      
      // Update state
      if (isEditing && editingPartner) {
        setEditingPartner({
          ...editingPartner,
          logo: publicUrl,
          useLocalImage: true,
          localImagePath: filePath
        });
      } else {
        setNewPartner({
          ...newPartner,
          logo: publicUrl,
          useLocalImage: true,
          localImagePath: filePath
        });
      }
      
      toast({
        title: "Image uploaded",
        description: "The image has been uploaded successfully."
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleAddPartner = () => {
    if (!newPartner.name || !newPartner.logo) {
      toast({
        title: "Missing information",
        description: "Partner name and logo are required.",
        variant: "destructive"
      });
      return;
    }

    const partner: Partner = {
      id: Date.now(),
      name: newPartner.name,
      logo: newPartner.logo,
      website: newPartner.website || "https://example.com",
      useLocalImage: newPartner.useLocalImage || false,
      localImagePath: newPartner.localImagePath
    };

    const updatedPartners = [...partners, partner];
    savePartners(updatedPartners);
    
    setNewPartner({
      name: '',
      logo: '',
      website: '',
      useLocalImage: false,
      localImagePath: undefined
    });

    toast({
      title: "Partner added",
      description: `${partner.name} has been added to partners.`
    });
  };

  const handleUpdatePartner = () => {
    if (!editingPartner) return;
    
    const updatedPartners = partners.map(p => 
      p.id === editingPartner.id ? editingPartner : p
    );
    
    savePartners(updatedPartners);
    setEditingPartner(null);
    
    toast({
      title: "Partner updated",
      description: `${editingPartner.name} has been updated.`
    });
  };

  const handleDeletePartner = (id: number) => {
    // Check if partner has a local image to delete from storage
    const partnerToDelete = partners.find(p => p.id === id);
    if (partnerToDelete?.useLocalImage && partnerToDelete.localImagePath) {
      // Delete from Supabase storage
      supabase.storage
        .from('admin_images')
        .remove([partnerToDelete.localImagePath])
        .then(({ error }) => {
          if (error) {
            console.error("Error removing file:", error);
          }
        });
    }
    
    // Remove from state
    const updatedPartners = partners.filter(p => p.id !== id);
    savePartners(updatedPartners);
    
    toast({
      title: "Partner removed",
      description: "The partner has been removed successfully."
    });
  };

  const handleEditChange = (field: keyof Partner, value: string | boolean) => {
    if (!editingPartner) return;
    setEditingPartner({ ...editingPartner, [field]: value });
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>, isEditing: boolean = false) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file, isEditing);
    }
  };

  const handleLocalImageToggle = (checked: boolean, isEditing: boolean = false) => {
    if (isEditing) {
      setEditingPartner({
        ...editingPartner!,
        useLocalImage: checked,
        logo: checked ? editingPartner!.logo : ''
      });
    } else {
      setNewPartner({
        ...newPartner,
        useLocalImage: checked,
        logo: checked ? newPartner.logo : ''
      });
    }
  };

  const triggerFileInput = (isEditing: boolean = false) => {
    if (isEditing) {
      editFileInputRef.current?.click();
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>, name: string) => {
    const target = e.target as HTMLImageElement;
    target.src = `https://via.placeholder.com/150x50?text=${name || 'Partner'}`;
  };

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Manage Partners</CardTitle>
          <CardDescription>
            Add, edit or remove partners from your website.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Logo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Website</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {partners.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    No partners found. Add your first partner using the form below.
                  </TableCell>
                </TableRow>
              ) : (
                partners.map((partner) => (
                  <TableRow key={partner.id}>
                    <TableCell>
                      <div className="w-16 h-12 flex items-center">
                        <img 
                          src={partner.logo} 
                          alt={partner.name} 
                          className="max-h-10 max-w-full object-contain"
                          onError={(e) => handleImageError(e, partner.name)} 
                        />
                      </div>
                    </TableCell>
                    <TableCell>{partner.name}</TableCell>
                    <TableCell>
                      <a 
                        href={partner.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-blue-500 hover:underline"
                      >
                        <span className="truncate max-w-[150px]">{partner.website}</span>
                        <ExternalLink size={14} />
                      </a>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => setEditingPartner(partner)}
                            >
                              <Edit size={16} />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Partner</DialogTitle>
                              <DialogDescription>
                                Make changes to the partner details below.
                              </DialogDescription>
                            </DialogHeader>
                            {editingPartner && (
                              <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-name">Partner Name</Label>
                                  <Input
                                    id="edit-name"
                                    value={editingPartner.name}
                                    onChange={(e) => handleEditChange('name', e.target.value)}
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between">
                                    <Label htmlFor="edit-local-image">Use Local Image</Label>
                                    <Switch
                                      id="edit-local-image"
                                      checked={editingPartner.useLocalImage || false}
                                      onCheckedChange={(checked) => handleLocalImageToggle(checked, true)}
                                    />
                                  </div>
                                </div>
                                
                                {editingPartner.useLocalImage ? (
                                  <div className="space-y-2">
                                    <Label>Upload Image</Label>
                                    <input
                                      type="file"
                                      ref={editFileInputRef}
                                      className="hidden"
                                      accept="image/*"
                                      onChange={(e) => handleFileInputChange(e, true)}
                                    />
                                    <div className="flex gap-2">
                                      <Button 
                                        type="button" 
                                        variant="outline"
                                        onClick={() => triggerFileInput(true)}
                                        className="w-full"
                                      >
                                        <Upload size={16} className="mr-2" />
                                        {editingPartner.logo ? 'Change Image' : 'Upload Image'}
                                      </Button>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="space-y-2">
                                    <Label htmlFor="edit-logo">Logo URL</Label>
                                    <Input
                                      id="edit-logo"
                                      value={editingPartner.logo}
                                      onChange={(e) => handleEditChange('logo', e.target.value)}
                                    />
                                  </div>
                                )}
                                
                                <div className="space-y-2">
                                  <Label htmlFor="edit-website">Website</Label>
                                  <div className="flex gap-2">
                                    <div className="flex-1">
                                      <Input
                                        id="edit-website"
                                        value={editingPartner.website}
                                        onChange={(e) => handleEditChange('website', e.target.value)}
                                      />
                                    </div>
                                    <Button
                                      variant="outline"
                                      size="icon"
                                      onClick={() => window.open(editingPartner.website, '_blank')}
                                    >
                                      <LinkIcon size={16} />
                                    </Button>
                                  </div>
                                </div>
                                
                                {editingPartner.logo && (
                                  <div className="pt-4">
                                    <Label>Preview</Label>
                                    <div className="mt-2 border rounded p-4 flex justify-center">
                                      <img
                                        src={editingPartner.logo}
                                        alt={editingPartner.name}
                                        className="max-h-16 object-contain"
                                        onError={(e) => handleImageError(e, editingPartner.name)}
                                      />
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                            <DialogFooter>
                              <Button type="submit" onClick={handleUpdatePartner}>
                                Save changes
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <Trash2 size={16} className="text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Partner</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to remove {partner.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => handleDeletePartner(partner.id)}
                                className="bg-destructive hover:bg-destructive/90"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add New Partner</CardTitle>
          <CardDescription>
            Add a new partner to your website.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Partner Name</Label>
                <Input
                  id="name"
                  value={newPartner.name}
                  onChange={(e) => setNewPartner({ ...newPartner, name: e.target.value })}
                  placeholder="Enter partner name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="website">Website URL</Label>
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Input
                      id="website"
                      value={newPartner.website}
                      onChange={(e) => setNewPartner({ ...newPartner, website: e.target.value })}
                      placeholder="https://example.com"
                    />
                  </div>
                  {newPartner.website && (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => window.open(newPartner.website, '_blank')}
                    >
                      <LinkIcon size={16} />
                    </Button>
                  )}
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="use-local-image">Use Local Image</Label>
                <Switch
                  id="use-local-image"
                  checked={newPartner.useLocalImage || false}
                  onCheckedChange={(checked) => handleLocalImageToggle(checked)}
                />
              </div>
            </div>
            
            {newPartner.useLocalImage ? (
              <div className="space-y-2">
                <Label>Upload Image</Label>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleFileInputChange}
                />
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => triggerFileInput()}
                  className="w-full"
                >
                  <Upload size={16} className="mr-2" />
                  {newPartner.logo ? 'Change Image' : 'Upload Image'}
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="logo">Logo URL</Label>
                <Input
                  id="logo"
                  value={newPartner.logo}
                  onChange={(e) => setNewPartner({ ...newPartner, logo: e.target.value })}
                  placeholder="Enter logo URL"
                />
              </div>
            )}
            
            {newPartner.logo && (
              <div className="pt-4">
                <Label>Preview</Label>
                <div className="mt-2 border rounded p-4 flex justify-center">
                  <img
                    src={newPartner.logo}
                    alt={newPartner.name || "Preview"}
                    className="max-h-16 object-contain"
                    onError={(e) => handleImageError(e, newPartner.name || "Preview")}
                  />
                </div>
              </div>
            )}
            
            <div className="pt-4 flex justify-end">
              <Button onClick={handleAddPartner} className="flex items-center gap-2">
                <Plus size={16} />
                Add Partner
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPartnersEditor;
