import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from '@/hooks/use-toast';
import supabase from '@/utils/supabaseClient';

const AdminTermsEditor = () => {
  const [terms, setTerms] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchTerms = async () => {
      try {
        const { data, error } = await supabase
          .from('site_content')
          .select('content')
          .eq('name', 'terms_of_service')
          .single();
        
        if (error) throw error;
        
        if (data) {
          setTerms(data.content);
        } else {
          // Initialize with placeholder content
          setTerms('# Terms of Service\n\nWelcome to Orcxi. By using our services, you agree to these terms.');
        }
      } catch (error) {
        console.error('Error fetching terms:', error);
        // Load from localStorage as fallback
        const savedTerms = localStorage.getItem('orcxi-terms');
        if (savedTerms) {
          setTerms(savedTerms);
        }
      }
    };

    fetchTerms();
  }, []);

  const handleSave = async () => {
    setIsLoading(true);
    try {
      // Save to Supabase
      const { error } = await supabase
        .from('site_content')
        .upsert({ 
          name: 'terms_of_service', 
          content: terms,
          updated_at: new Date().toISOString()
        });
      
      if (error) throw error;

      // Save to localStorage as backup
      localStorage.setItem('orcxi-terms', terms);
      
      toast({
        title: "Terms of Service saved",
        description: "Your changes have been successfully saved."
      });
    } catch (error) {
      console.error('Error saving terms:', error);
      toast({
        title: "Error saving Terms of Service",
        description: "There was a problem saving your changes. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Edit Terms of Service</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Textarea 
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              className="min-h-[500px] font-mono"
              placeholder="Enter your Terms of Service content here..."
            />
            <Button 
              onClick={handleSave}
              disabled={isLoading}
              className="w-full sm:w-auto"
            >
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminTermsEditor;
