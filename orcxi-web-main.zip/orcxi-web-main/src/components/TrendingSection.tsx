
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, TrendingUp } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { TrendingTopic } from '@/models/Partner';
import { Link } from 'react-router-dom';

const defaultTrendingTopics: TrendingTopic[] = [
  {
    id: 1,
    title: "Vibe Coding",
    description: "The new way developers are creating relaxing work environments",
    imageUrl: "https://via.placeholder.com/400x300?text=Vibe+Coding",
    link: "#"
  },
  {
    id: 2,
    title: "AI-Assisted Development",
    description: "How artificial intelligence is changing the way we build software",
    imageUrl: "https://via.placeholder.com/400x300?text=AI+Development",
    link: "#"
  },
  {
    id: 3,
    title: "Low-Code Evolution",
    description: "The rise of platforms enabling faster app development",
    imageUrl: "https://via.placeholder.com/400x300?text=Low+Code",
    link: "#"
  }
];

const TrendingSection = () => {
  const [trendingTopics, setTrendingTopics] = useState<TrendingTopic[]>([]);
  
  useEffect(() => {
    // In a real app, you would fetch this from an API or database
    const savedTopics = localStorage.getItem('orcxi-trending');
    setTrendingTopics(savedTopics ? JSON.parse(savedTopics) : defaultTrendingTopics);
  }, []);
  
  return (
    <section className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
          <div className="space-y-4 mb-6 md:mb-0">
            <div className="inline-flex items-center rounded-full bg-secondary px-3 py-1 text-sm mb-2">
              <TrendingUp className="w-4 h-4 mr-1 text-primary" />
              <span className="text-muted-foreground">Hot topics</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold">What's Trending</h2>
            <p className="text-muted-foreground max-w-2xl">
              Stay updated with the latest trends in technology and business.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {trendingTopics.map((topic) => (
            <motion.div 
              key={topic.id}
              whileHover={{ y: -5 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="overflow-hidden h-full">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={topic.imageUrl || "https://via.placeholder.com/400x300?text=Trending"} 
                    alt={topic.title} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <CardContent className="p-6 space-y-3">
                  <h3 className="text-xl font-bold">{topic.title}</h3>
                  <p className="text-muted-foreground">{topic.description}</p>
                  <a 
                    href={topic.link || "#"} 
                    className="inline-flex items-center text-primary hover:underline transition-all"
                  >
                    <span>Read more</span>
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingSection;
