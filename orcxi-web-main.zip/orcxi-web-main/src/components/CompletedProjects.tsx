
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import ProjectCard from './ProjectCard';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from "@/components/ui/card";

interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  image: string;
  link: string;
  github?: string;
  featured: boolean;
}

const CompletedProjects = () => {
  const { isAdmin } = useAuth();
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 1,
      title: "E-Commerce Platform",
      description: "A full-featured online shopping platform with payment integration and inventory management.",
      tags: ["React", "Node.js", "MongoDB"],
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d",
      link: "#",
      github: "#",
      featured: true
    },
    {
      id: 2,
      title: "CRM System",
      description: "Customer relationship management system with analytics dashboard and lead tracking.",
      tags: ["React", "TypeScript", "Firebase"],
      image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b",
      link: "#",
      github: "#",
      featured: false
    },
    {
      id: 3,
      title: "HR Management Portal",
      description: "Employee management system with attendance tracking, payroll, and performance reviews.",
      tags: ["Vue.js", "Express", "PostgreSQL"],
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158",
      link: "#",
      featured: true
    }
  ]);
  
  useEffect(() => {
    // Load projects from local storage if available
    const savedProjects = localStorage.getItem('orcxi-projects');
    if (savedProjects) {
      setProjects(JSON.parse(savedProjects));
    }
  }, []);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
          <div className="space-y-4 mb-6 md:mb-0">
            <h2 className="text-3xl md:text-4xl font-bold">Completed Projects</h2>
            <p className="text-muted-foreground max-w-2xl">
              A showcase of our successful business solutions delivered to clients.
            </p>
          </div>
        </div>
        
        {/* Projects Counter Card */}
        <motion.div 
          className="mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-gradient-blue text-white overflow-hidden">
            <CardContent className="p-8 flex flex-col md:flex-row items-center justify-between">
              <div className="flex items-center gap-4 mb-4 md:mb-0">
                <div className="bg-white/20 p-3 rounded-full">
                  <CheckCircle className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Completed Projects</h3>
                  <p className="text-white/80">Successfully delivered business solutions</p>
                </div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold">{projects.length}</div>
                <p className="text-white/80">Total Projects</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {projects.map((project) => (
            <motion.div 
              key={project.id} 
              variants={itemVariants}
            >
              <ProjectCard 
                title={project.title}
                description={project.description}
                tags={project.tags}
                image={project.image || "https://via.placeholder.com/800x600?text=Project+Image"}
                link={project.link}
                github={project.github}
                featured={project.featured}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default CompletedProjects;
