
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const Logo = ({ className, size = 'lg' }: LogoProps) => {
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-20 w-20',
    xl: 'h-32 w-32',
  };

  return (
    <motion.div 
      className={cn('relative rounded-full overflow-hidden shadow-glowing', sizeClasses[size], className)}
      animate={{ 
        boxShadow: ['0 0 10px 2px rgba(59, 130, 246, 0.3)', '0 0 20px 4px rgba(59, 130, 246, 0.5)', '0 0 10px 2px rgba(59, 130, 246, 0.3)']
      }}
      transition={{ 
        duration: 3, 
        repeat: Infinity, 
        ease: "easeInOut" 
      }}
    >
      <div className="absolute inset-0 bg-gradient-blue rounded-full">
        <motion.div 
          className="absolute inset-x-0 bottom-0 h-1/2 bg-white/30 wave-effect"
          animate={{
            y: [0, 5, 0]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="absolute h-2 w-full bg-white/20 rounded-full transform translate-y-1"></div>
          <div className="absolute h-3 w-full bg-white/10 rounded-full transform translate-y-3"></div>
          <div className="absolute h-4 w-full bg-white/5 rounded-full transform translate-y-5"></div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Logo;
