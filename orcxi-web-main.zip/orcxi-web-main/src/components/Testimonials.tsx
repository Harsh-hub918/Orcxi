import React, { useState, useRef } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from "@/hooks/use-toast";
import { PlusCircle, Check, X, MapPin, Upload, Edit } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';

type Testimonial = {
  id: string;
  name: string;
  handle: string;
  message: string;
  avatarUrl: string;
  location: string;
};

const Testimonials = () => {
  const { toast } = useToast();
  const { isAdmin } = useAuth();
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [avatarUrl, setAvatarUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newTestimonial, setNewTestimonial] = useState({
    name: '',
    handle: '',
    message: '',
    location: 'Pune, Maharashtra, India'
  });
  const [testimonials, setTestimonials] = useState<Testimonial[]>([
    {
      id: '1',
      name: 'Rahul Sharma',
      handle: '@rahulsharma',
      message: 'Orcxi has transformed how our business handles client relationships. The intuitive interface and powerful features have increased our productivity by 40% in just three months.',
      avatarUrl: '',
      location: 'Mumbai, Maharashtra, India'
    },
    {
      id: '2',
      name: 'Priya Patel',
      handle: '@priyapatel',
      message: 'As a startup founder, finding the right business tools is critical. Orcxi provided exactly what we needed at a price point that made sense for our budget. Highly recommended!',
      avatarUrl: '',
      location: 'Pune, Maharashtra, India'
    },
    {
      id: '3',
      name: 'Vikram Desai',
      handle: '@vikramdesai',
      message: 'The customer support team at Orcxi is exceptional. They helped us customize the platform to our specific requirements and were always available when we needed assistance.',
      avatarUrl: '',
      location: 'Bangalore, India'
    }
  ]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (isEditing) {
      setTestimonials(prev => prev.map(t => 
        t.id === isEditing ? { ...t, [name]: value } : t
      ));
    } else {
      setNewTestimonial(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleAvatarUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isEditing) {
      const id = isEditing;
      setTestimonials(prev => prev.map(t => 
        t.id === id ? { ...t, avatarUrl: e.target.value } : t
      ));
    } else {
      setAvatarUrl(e.target.value);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      if (isEditing) {
        setTestimonials(prev => prev.map(t => 
          t.id === isEditing ? { ...t, avatarUrl: base64String } : t
        ));
      } else {
        setAvatarUrl(base64String);
      }
    };
    reader.readAsDataURL(file);
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleAddTestimonial = () => {
    if (!newTestimonial.name || !newTestimonial.handle || !newTestimonial.message) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const newEntry: Testimonial = {
      id: Date.now().toString(),
      name: newTestimonial.name,
      handle: newTestimonial.handle,
      message: newTestimonial.message,
      avatarUrl: avatarUrl,
      location: newTestimonial.location
    };

    setTestimonials(prev => [newEntry, ...prev]);
    setNewTestimonial({
      name: '',
      handle: '',
      message: '',
      location: 'Pune, Maharashtra, India'
    });
    setAvatarUrl('');
    setIsAdding(false);

    toast({
      title: "Testimonial added",
      description: "Thank you for sharing your experience!",
    });
  };

  const handleEditTestimonial = () => {
    setIsEditing(null);
    toast({
      title: "Testimonial updated",
      description: "The testimonial has been successfully updated.",
    });
  };

  const startEditing = (id: string) => {
    setIsEditing(id);
    setIsAdding(false);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const getCurrentTestimonial = () => {
    if (isEditing) {
      return testimonials.find(t => t.id === isEditing);
    }
    return null;
  };

  const currentTestimonial = getCurrentTestimonial();

  return (
    <div className="w-full">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
        <div className="space-y-4 mb-6 md:mb-0">
          <h2 className="text-3xl md:text-4xl font-bold">Client Testimonials</h2>
          <p className="text-muted-foreground max-w-2xl">
            Hear what our clients have to say about Orcxi business solutions.
          </p>
        </div>
        <Button 
          variant="outline" 
          onClick={() => {
            setIsAdding(!isAdding);
            setIsEditing(null);
          }}
          className="flex items-center gap-2"
        >
          {isAdding ? (
            <>
              <X className="h-4 w-4" /> Cancel
            </>
          ) : (
            <>
              <PlusCircle className="h-4 w-4" /> Add Testimonial
            </>
          )}
        </Button>
      </div>

      {/* Hidden file input for image uploads */}
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={handleFileUpload}
      />

      {(isAdding || isEditing) && (
        <motion.div 
          className="bg-background rounded-2xl shadow-soft p-6 mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="text-xl font-bold mb-4">
            {isEditing ? "Edit Testimonial" : "Share Your Experience"}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-1">Full Name</label>
                <Input 
                  id="name" 
                  name="name" 
                  value={isEditing ? currentTestimonial?.name || '' : newTestimonial.name} 
                  onChange={handleInputChange} 
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="handle" className="block text-sm font-medium mb-1">Handle</label>
                <Input 
                  id="handle" 
                  name="handle" 
                  value={isEditing ? currentTestimonial?.handle || '' : newTestimonial.handle} 
                  onChange={handleInputChange} 
                  placeholder="@johndoe"
                />
              </div>
              <div>
                <label htmlFor="location" className="block text-sm font-medium mb-1">Location</label>
                <Input 
                  id="location" 
                  name="location" 
                  value={isEditing ? currentTestimonial?.location || '' : newTestimonial.location} 
                  onChange={handleInputChange} 
                  placeholder="Pune, Maharashtra, India"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-medium">Avatar Image</label>
                <div className="flex flex-col space-y-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={triggerFileInput}
                    className="w-full flex items-center justify-center"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Choose Image File
                  </Button>
                  <div className="relative">
                    <Input 
                      value={isEditing ? currentTestimonial?.avatarUrl || '' : avatarUrl} 
                      onChange={handleAvatarUrlChange} 
                      placeholder="Or paste image URL here"
                      className="pr-10"
                    />
                    {(isEditing ? currentTestimonial?.avatarUrl : avatarUrl) && (
                      <button 
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-red-500"
                        onClick={() => isEditing 
                          ? setTestimonials(prev => prev.map(t => t.id === isEditing ? { ...t, avatarUrl: '' } : t))
                          : setAvatarUrl('')
                        }
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Upload an image or paste a direct URL to your avatar
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-1">Your Testimonial</label>
                <Textarea 
                  id="message" 
                  name="message" 
                  value={isEditing ? currentTestimonial?.message || '' : newTestimonial.message} 
                  onChange={handleInputChange} 
                  placeholder="Share your experience with Orcxi..."
                  className="h-32"
                />
              </div>
              <div className="pt-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage 
                      src={isEditing ? currentTestimonial?.avatarUrl || '' : avatarUrl} 
                      alt="Preview" 
                    />
                    <AvatarFallback>
                      {isEditing 
                        ? currentTestimonial?.name.charAt(0) || '' 
                        : newTestimonial.name.charAt(0) || '?'
                      }
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-sm">
                    <p className="font-medium">
                      {isEditing ? currentTestimonial?.name || 'Name' : newTestimonial.name || 'Your Name'}
                    </p>
                    <p className="text-muted-foreground">
                      {isEditing ? currentTestimonial?.handle || '@handle' : newTestimonial.handle || '@handle'}
                    </p>
                  </div>
                </div>
                <Button onClick={isEditing ? handleEditTestimonial : handleAddTestimonial}>
                  <Check className="h-4 w-4 mr-2" /> {isEditing ? 'Save Changes' : 'Submit'}
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {testimonials.map(testimonial => (
          <motion.div key={testimonial.id} variants={itemVariants}>
            <Card className="h-full flex flex-col rounded-2xl overflow-hidden hover:shadow-strong transition-all duration-300 group relative">
              {isAdmin && (
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="h-8 w-8 rounded-full"
                    onClick={() => startEditing(testimonial.id)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              )}
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatarUrl} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.handle}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="italic text-muted-foreground">"{testimonial.message}"</p>
              </CardContent>
              <CardFooter className="pt-0 text-xs text-muted-foreground flex items-center">
                <MapPin className="h-3 w-3 mr-1" /> {testimonial.location}
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default Testimonials;
