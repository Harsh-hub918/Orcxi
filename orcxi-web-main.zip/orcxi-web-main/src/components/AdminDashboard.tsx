
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, HandshakeIcon, ShieldCheck, Briefcase, Award, FileText, Users, Mail, Info } from 'lucide-react';
import { ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar, LineChart, Line, AreaChart, Area } from 'recharts';
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "react-router-dom";
import { Service } from "@/models/Service";
import supabase from '@/utils/supabaseClient';

const AdminDashboard = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [liveUsers, setLiveUsers] = useState(Math.floor(Math.random() * 15) + 5);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Track page view
  useEffect(() => {
    const trackPageView = async () => {
      try {
        await supabase.from('page_views').insert({
          page: 'admin-dashboard',
          user_agent: navigator.userAgent,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Error tracking page view:', error);
      }
    };
    
    trackPageView();
  }, []);

  // Load services 
  useEffect(() => {
    // Load services from localStorage
    const savedServices = localStorage.getItem('orcxi-services');
    const defaultServices = [
      {
        id: 1,
        title: "Web Development",
        description: "Custom websites and web applications with responsive design",
        icon: "code",
        image: "https://via.placeholder.com/640x360?text=Web+Development",
        features: ["Responsive Design", "SEO Optimization", "CMS Integration"]
      },
      {
        id: 2,
        title: "UI/UX Design",
        description: "User-centered design that enhances engagement and conversion",
        icon: "layout",
        image: "https://via.placeholder.com/640x360?text=UI/UX+Design",
        features: ["User Research", "Wireframing", "Prototyping"]
      },
      {
        id: 3,
        title: "Business Consulting",
        description: "Strategic guidance for digital transformation and growth",
        icon: "briefcase",
        image: "https://via.placeholder.com/640x360?text=Business+Consulting",
        features: ["Growth Strategy", "Process Optimization", "Market Analysis"]
      }
    ];
    setServices(savedServices ? JSON.parse(savedServices) : defaultServices);
    
    // Simulate live user count updates
    const interval = setInterval(() => {
      setLiveUsers(prev => {
        const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
        return Math.max(3, prev + change);
      });
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Get subscriber count
  useEffect(() => {
    const getSubscribers = async () => {
      try {
        const { count, error } = await supabase
          .from('subscribers')
          .select('*', { count: 'exact', head: true });
        
        if (error) throw error;
        
        setSubscriberCount(count || 0);
      } catch (error) {
        console.error('Error fetching subscriber count:', error);
      }
    };
    
    getSubscribers();
  }, []);
  
  // Function to refresh data
  const refreshData = async () => {
    setIsRefreshing(true);
    try {
      // Refresh subscriber count
      const { count, error } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true });
      
      if (error) throw error;
      
      setSubscriberCount(count || 0);
    } catch (error) {
      console.error('Error refreshing data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Enhanced data for charts
  const visitorsData = [
    { month: 'Jan', visitors: 1200, leads: 320 },
    { month: 'Feb', visitors: 1900, leads: 480 },
    { month: 'Mar', visitors: 3000, leads: 720 },
    { month: 'Apr', visitors: 5000, leads: 1100 },
    { month: 'May', visitors: 4000, leads: 900 },
    { month: 'Jun', visitors: 6500, leads: 1400 },
  ];

  const engagementData = [
    { day: 'Mon', pageViews: 340, uniqueVisitors: 120 },
    { day: 'Tue', pageViews: 290, uniqueVisitors: 105 },
    { day: 'Wed', pageViews: 410, uniqueVisitors: 145 },
    { day: 'Thu', pageViews: 520, uniqueVisitors: 180 },
    { day: 'Fri', pageViews: 570, uniqueVisitors: 210 },
    { day: 'Sat', pageViews: 480, uniqueVisitors: 170 },
    { day: 'Sun', pageViews: 390, uniqueVisitors: 140 },
  ];
  
  // Real-time data simulation
  const realtimeData = [
    { time: '09:00', users: 12 },
    { time: '10:00', users: 18 },
    { time: '11:00', users: 22 },
    { time: '12:00', users: 25 },
    { time: '13:00', users: 30 },
    { time: '14:00', users: 27 },
    { time: '15:00', users: liveUsers },
  ];

  const statsCards = [
    { title: 'Blog Posts', value: '24', icon: BookOpen, description: 'Published articles', link: '/admin/blog' },
    { title: 'Services', value: services.length.toString(), icon: FileText, description: 'Service offerings', link: '/admin/services' },
    { title: 'Partners', value: '9', icon: HandshakeIcon, description: 'Business partners', link: '/admin/partners' },
    { title: 'Subscribers', value: subscriberCount.toString(), icon: Mail, description: 'Email subscribers', link: '/admin/subscribers' },
    { title: 'Live Users', value: liveUsers.toString(), icon: Users, description: 'Simulated user data', link: null },
  ];

  return (
    <div className="space-y-6">
      {/* Info Alert */}
      <Alert className="bg-blue-50 border-blue-200">
        <Info className="h-4 w-4 text-blue-500" />
        <AlertDescription className="text-blue-700">
          Active user data is simulated for demonstration purposes.
        </AlertDescription>
      </Alert>
      
      {/* Refresh Button */}
      <div className="flex justify-end">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={refreshData} 
          disabled={isRefreshing}
          className="flex items-center gap-2"
        >
          <svg 
            className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`}
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          {isRefreshing ? 'Refreshing...' : 'Refresh Data'}
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-5">
        {statsCards.map((card, index) => (
          <Card key={index} className="overflow-hidden border-l-4 border-l-primary shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0 bg-muted/10">
              <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              <card.icon className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{card.value}</div>
              <p className="text-xs text-muted-foreground">{card.description}</p>
              {card.link && (
                <Link to={card.link} className="text-xs text-primary hover:underline mt-2 inline-block">
                  View details →
                </Link>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Real-time Website Traffic */}
      <Card className="shadow-sm hover:shadow-md transition-shadow">
        <CardHeader>
          <CardTitle>Real-time Website Traffic</CardTitle>
          <CardDescription>Simulated active users on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={realtimeData}>
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#3b82f6" 
                  fillOpacity={1} 
                  fill="url(#colorUsers)" 
                  name="Active Users" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Services */}
      <Card className="shadow-sm hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Featured Services</CardTitle>
            <CardDescription>Most popular services offered by Orcxi</CardDescription>
          </div>
          <Link to="/admin/services">
            <Button variant="outline" size="sm">
              Manage Services
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            {services.slice(0, 3).map((service, index) => (
              <Card key={index} className="bg-muted/5 border-none shadow-sm hover:shadow transition-shadow">
                <CardHeader className="flex flex-row items-start pb-2 space-y-0">
                  <div className="p-2 bg-primary/10 rounded-md mr-3">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-base">{service.title}</CardTitle>
                    <CardDescription className="text-xs mt-1">
                      {service.description}
                    </CardDescription>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Historical Data Charts */}
      <Tabs defaultValue="visitors" className="w-full">
        <TabsList className="w-full justify-start mb-4 overflow-x-auto flex-nowrap">
          <TabsTrigger value="visitors">Traffic Analytics</TabsTrigger>
          <TabsTrigger value="engagement">User Engagement</TabsTrigger>
        </TabsList>
        
        <TabsContent value="visitors" className="pt-4">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle>Website Traffic</CardTitle>
              <CardDescription>Monthly visitor statistics for the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={visitorsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="visitors" 
                      stroke="#3b82f6" 
                      strokeWidth={2} 
                      activeDot={{ r: 6 }} 
                      name="Total Visitors"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="leads" 
                      stroke="#10b981" 
                      strokeWidth={2} 
                      activeDot={{ r: 6 }} 
                      name="Qualified Leads"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="engagement" className="pt-4">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle>Weekly Engagement</CardTitle>
              <CardDescription>Page views per day for the last week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={engagementData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar 
                      dataKey="pageViews" 
                      fill="#10b981" 
                      name="Page Views"
                      barSize={20}
                    />
                    <Bar 
                      dataKey="uniqueVisitors" 
                      fill="#6366f1" 
                      name="Unique Visitors"
                      barSize={20}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
