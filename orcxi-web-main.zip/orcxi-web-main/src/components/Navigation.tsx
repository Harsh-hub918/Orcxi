
import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Shield, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import ThemeToggle from './ThemeToggle';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

type NavItem = {
  name: string;
  path: string;
  icon?: React.ElementType;
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { isAdmin, logout } = useAuth();
  const { toast } = useToast();

  const navItems: NavItem[] = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  // Add Admin link only if user is authenticated
  const allNavItems = isAdmin 
    ? [...navItems, { name: 'Admin', path: '/admin', icon: Shield }] 
    : navItems;

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been logged out of the admin panel."
    });
  };

  const handleNavigation = (path: string) => {
    // Scroll to top when navigating
    window.scrollTo(0, 0);
    navigate(path);
  };

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setScrolled(offset > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Close menu when route changes
    setIsOpen(false);
  }, [location]);

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 md:px-12 py-4',
        scrolled ? 'bg-background/80 backdrop-blur-lg shadow-soft' : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link 
          to="/" 
          className="text-foreground hover:text-primary transition-colors flex items-center space-x-2 interactive"
          onClick={() => window.scrollTo(0, 0)}
        >
          <div className="flex items-center space-x-3">
            <div className="relative h-10 w-10 overflow-hidden rounded-full bg-gradient-blue shadow-glowing animate-pulse">
              <div className="absolute inset-x-0 bottom-0 h-1/2 bg-white/30 rounded-t-full"></div>
            </div>
            <span className="font-display font-bold text-xl tracking-tight">Orcxi</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        {!isMobile && (
          <nav className="hidden md:flex items-center space-x-1">
            {allNavItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.path)}
                className={cn(
                  "relative px-4 py-2 rounded-full text-foreground hover:text-primary transition-colors duration-300 flex items-center interactive",
                  location.pathname === item.path ? "text-primary font-medium" : ""
                )}
              >
                {item.icon && <item.icon className="w-4 h-4 mr-1" />}
                {item.name}
                {location.pathname === item.path && (
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                )}
              </button>
            ))}
            
            {isAdmin && (
              <button
                onClick={handleLogout}
                className="px-4 py-2 rounded-full text-foreground hover:text-primary transition-colors duration-300 flex items-center interactive"
              >
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </button>
            )}
            
            <ThemeToggle className="ml-2" />
          </nav>
        )}

        {/* Mobile Navigation Toggle */}
        {isMobile && (
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <button
              className="md:hidden p-2 rounded-full bg-secondary text-foreground hover:bg-secondary/80 transition-colors interactive"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle Menu"
            >
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        )}

        {/* Mobile Navigation Menu */}
        {isMobile && (
          <div
            className={cn(
              "fixed inset-0 bg-background/95 backdrop-blur-lg z-50 transition-transform duration-300 ease-in-out transform",
              isOpen ? "translate-x-0" : "translate-x-full"
            )}
          >
            <div className="flex flex-col h-full justify-center items-center p-8">
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-6 right-6 p-2 rounded-full bg-secondary text-foreground hover:bg-secondary/80 transition-colors interactive"
                aria-label="Close Menu"
              >
                <X size={20} />
              </button>
              
              <nav className="flex flex-col space-y-6 text-center">
                {allNavItems.map((item) => (
                  <button
                    key={item.name}
                    onClick={() => handleNavigation(item.path)}
                    className={cn(
                      "text-2xl font-display transition-colors duration-300 flex items-center justify-center interactive",
                      location.pathname === item.path 
                        ? "text-primary font-medium" 
                        : "text-foreground hover:text-primary"
                    )}
                  >
                    {item.icon && <item.icon className="w-5 h-5 mr-2" />}
                    {item.name}
                  </button>
                ))}
                
                {isAdmin && (
                  <button
                    onClick={handleLogout}
                    className="text-2xl font-display transition-colors duration-300 flex items-center justify-center text-foreground hover:text-primary interactive"
                  >
                    <LogOut className="w-5 h-5 mr-2" />
                    Logout
                  </button>
                )}
              </nav>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navigation;
