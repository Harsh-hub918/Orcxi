import { useState, useEffect } from 'react';
import { Plus, Trash2, Save } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress"; 
import { useToast } from '@/hooks/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import supabase from '@/utils/supabaseClient';

interface Skill {
  id: string;
  name: string;
  proficiency: number;
}

const AdminSkillsEditor = () => {
  const [skills, setSkills] = useState<Skill[]>([]);
  const [newSkill, setNewSkill] = useState({ name: '', proficiency: 75 });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    const fetchSkills = async () => {
      try {
        const { data, error } = await supabase
          .from('skills')
          .select('*')
          .order('name');
        
        if (error) throw error;
        
        if (data) {
          setSkills(data);
        } else {
          // Load from localStorage as fallback
          const savedSkills = localStorage.getItem('orcxi-skills');
          if (savedSkills) {
            setSkills(JSON.parse(savedSkills));
          } else {
            // Default skills
            setSkills([
              { id: '1', name: 'Web Development', proficiency: 90 },
              { id: '2', name: 'UI/UX Design', proficiency: 85 },
              { id: '3', name: 'Digital Marketing', proficiency: 75 }
            ]);
          }
        }
      } catch (error) {
        console.error('Error fetching skills:', error);
        toast({
          title: "Error fetching skills",
          description: "Could not load skills from the database.",
          variant: "destructive"
        });
        
        // Load from localStorage as fallback
        const savedSkills = localStorage.getItem('orcxi-skills');
        if (savedSkills) {
          setSkills(JSON.parse(savedSkills));
        }
      }
    };
    
    fetchSkills();
  }, [toast]);
  
  const handleAddSkill = async () => {
    if (!newSkill.name.trim()) {
      toast({
        title: "Error",
        description: "Skill name cannot be empty",
        variant: "destructive"
      });
      return;
    }
    
    const skillToAdd = {
      id: Date.now().toString(),
      name: newSkill.name,
      proficiency: newSkill.proficiency
    };
    
    setLoading(true);
    
    try {
      // Add to Supabase
      const { error } = await supabase
        .from('skills')
        .insert([skillToAdd]);
      
      if (error) throw error;
      
      // Update state and localStorage
      const updatedSkills = [...skills, skillToAdd];
      setSkills(updatedSkills);
      localStorage.setItem('orcxi-skills', JSON.stringify(updatedSkills));
      
      // Reset form
      setNewSkill({ name: '', proficiency: 75 });
      
      toast({
        title: "Skill added",
        description: `${skillToAdd.name} has been added to your skills.`
      });
    } catch (error) {
      console.error('Error adding skill:', error);
      toast({
        title: "Error adding skill",
        description: "There was a problem adding the skill. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleDeleteSkill = async (id: string) => {
    setLoading(true);
    
    try {
      // Delete from Supabase
      const { error } = await supabase
        .from('skills')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      // Update state and localStorage
      const updatedSkills = skills.filter(skill => skill.id !== id);
      setSkills(updatedSkills);
      localStorage.setItem('orcxi-skills', JSON.stringify(updatedSkills));
      
      toast({
        title: "Skill deleted",
        description: "The skill has been removed from your profile."
      });
    } catch (error) {
      console.error('Error deleting skill:', error);
      toast({
        title: "Error deleting skill",
        description: "There was a problem deleting the skill. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSkillChange = (id: string, field: keyof Skill, value: any) => {
    const updatedSkills = skills.map(skill => {
      if (skill.id === id) {
        return { ...skill, [field]: value };
      }
      return skill;
    });
    
    setSkills(updatedSkills);
  };
  
  const handleSaveChanges = async () => {
    setLoading(true);
    
    try {
      // Update Supabase with all skills (brute force approach)
      // In a real app, you'd want to only update what's changed
      const { error } = await supabase
        .from('skills')
        .upsert(skills);
      
      if (error) throw error;
      
      // Update localStorage
      localStorage.setItem('orcxi-skills', JSON.stringify(skills));
      
      toast({
        title: "Changes saved",
        description: "Your skills have been updated successfully."
      });
    } catch (error) {
      console.error('Error saving skills:', error);
      toast({
        title: "Error saving changes",
        description: "There was a problem saving your changes. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Add New Skill</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            <div className="md:col-span-5">
              <Input
                placeholder="Skill name"
                value={newSkill.name}
                onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })}
              />
            </div>
            <div className="md:col-span-5">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Proficiency</span>
                  <span className="text-sm font-semibold">{newSkill.proficiency}%</span>
                </div>
                <Slider
                  value={[newSkill.proficiency]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(values) => setNewSkill({ ...newSkill, proficiency: values[0] })}
                />
                <Progress value={newSkill.proficiency} className="h-2" />
              </div>
            </div>
            <div className="md:col-span-2">
              <Button 
                onClick={handleAddSkill}
                disabled={loading || !newSkill.name.trim()}
                className="w-full"
              >
                <Plus className="mr-2 h-4 w-4" /> Add
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Manage Skills</CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleSaveChanges}
            disabled={loading}
          >
            <Save className="mr-2 h-4 w-4" />
            Save Changes
          </Button>
        </CardHeader>
        <CardContent>
          {skills.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              No skills added yet. Add your first skill above.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Skill</TableHead>
                  <TableHead>Proficiency</TableHead>
                  <TableHead className="w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {skills.map((skill) => (
                  <TableRow key={skill.id}>
                    <TableCell>
                      <Input
                        value={skill.name}
                        onChange={(e) => handleSkillChange(skill.id, 'name', e.target.value)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs">{skill.proficiency}%</span>
                        </div>
                        <Slider
                          value={[skill.proficiency]}
                          min={0}
                          max={100}
                          step={1}
                          onValueChange={(values) => handleSkillChange(skill.id, 'proficiency', values[0])}
                        />
                        <Progress value={skill.proficiency} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteSkill(skill.id)}
                        disabled={loading}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSkillsEditor;
