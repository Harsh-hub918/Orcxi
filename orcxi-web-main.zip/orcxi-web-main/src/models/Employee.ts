
export interface Employee {
  id: number;
  name: string;
  position: string; // Used for job title
  photo: string;   // URL to employee photo
  bio: string;
  role?: string;    // Legacy field for backward compatibility
  image?: string;   // Legacy field for backward compatibility
  linkedin?: string;
  twitter?: string;
  email?: string;
  socialLinks?: {
    linkedin?: string;
    twitter?: string;
    github?: string;
  };
}
