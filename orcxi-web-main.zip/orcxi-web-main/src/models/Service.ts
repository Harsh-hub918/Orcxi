
export interface Service {
  id: number;
  title: string;
  description: string;
  icon?: string;
  image?: string;
  features?: string[];
}
