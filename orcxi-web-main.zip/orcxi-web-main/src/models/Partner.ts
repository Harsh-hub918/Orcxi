
export interface Partner {
  id: number;
  name: string;
  logo: string;
  website?: string;
  useLocalImage?: boolean;
  localImagePath?: string;
}

export interface TrendingTopic {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  link?: string;
}
