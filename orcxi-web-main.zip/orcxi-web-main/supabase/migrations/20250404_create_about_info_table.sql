
-- Create a table for storing the About page information
CREATE TABLE IF NOT EXISTS public.about_info (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    info JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Set up Row Level Security (RLS)
ALTER TABLE public.about_info ENABLE ROW LEVEL SECURITY;

-- Create policy to allow authenticated users to view the about info
CREATE POLICY "Allow all users to view about info" ON public.about_info
    FOR SELECT USING (true);

-- Create policy to allow authenticated users to insert about info
-- Since this is admin only, we can limit this later with custom claims or roles
CREATE POLICY "Allow authenticated users to insert about info" ON public.about_info
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Create policy to allow authenticated users to update about info
CREATE POLICY "Allow authenticated users to update about info" ON public.about_info
    FOR UPDATE USING (auth.role() = 'authenticated');
